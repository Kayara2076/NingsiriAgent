# 🎼 The Beginner’s Master Playbook: Zero-to-Live Setup Guide

Welcome! Think of me as the **composer/architect** and yourself as the **conductor**.  
**Good news:** You do **NOT** need to write any code, edit terminal config files, or invent AI prompts from scratch. All the Python code, FFmpeg video editing logic, and AI prompts are **already pre-built inside your `viral-commerce-agent` folder**.

Your only job is to **turn the engine on** and **paste your account keys into the visual `/setup` page** step by step.

---

## 🗺️ How All the Pieces Fit Together (In Plain English)

1. **The Control Room (`http://localhost:8000` & `/setup`):** Your visual website where you paste your keys, watch preview videos, and click **"Approve & Publish"** on shortlisted viral products.
2. **The Video Factory (Built-in FFmpeg + Free Neural Voice):** Automatically turns AI scripts + images into vertical `9:16` animated videos with moving cameras, background music, and bold pop-in captions for **$0/video**.
3. **The Autopilot Scheduler (`n8n` at `http://localhost:5678`):** A visual timer & messenger that wakes up every day, triggers the Video Factory & Product Hunter, waits for peak viral hours, posts to your social media, and sends your daily WhatsApp/Email summary.

---

## 🏁 PHASE 1: Turn On Your Agent Engine (10 Minutes)

You can start **for free on your own computer today** to test everything, and later move it to a **$6/month cloud server (VPS)** when you want it running 24/7 while your laptop is off.

### Step 1.1 — Download Your Ready-Made Agent Package
Download `viral-commerce-agent-complete.zip` from this workspace (or click **⬇ Download Complete Project (.zip)** at the top of the `/setup` page) and unzip it to your Desktop.

### Step 1.2 — Install Docker Desktop (Free — Only Done Once)
Docker is a free app that runs both `n8n` and the `FFmpeg Video Factory` inside one neat box so you never have to install Python or FFmpeg manually.
1. Go to **[docker.com/products/docker-desktop](https://www.docker.com/products/docker-desktop/)**, download it for Windows or Mac, install it, and **open Docker Desktop** until the bottom-left whale icon turns green/steady.

### Step 1.3 — Double-Click the 1-Click Starter
Open your unzipped `viral-commerce-agent` folder:
- **On Windows:** Double-click **`start-agent.bat`**
- **On Mac / Linux:** Open Terminal inside that folder and paste:
  ```bash
  bash start-agent.sh
  ```
*(Wait ~1–2 minutes the very first time while Docker downloads n8n and FFmpeg).*

When it says **SUCCESS**, open these two tabs in Chrome/Edge:
- **Tab A (Your Setup Wizard):** `http://localhost:8000/setup`
- **Tab B (Your n8n Canvas):** `http://localhost:5678`

---

## 🧠 PHASE 2: Connect the Free AI Brain & Push the 4 Workflows (5 Minutes)

### Step 2.1 — Get a Free AI Brain Key (Groq — $0.00 Cost!)
Your agent needs an AI brain to write viral hooks, hashtags, and store descriptions.
1. Go to **[console.groq.com/keys](https://console.groq.com/keys)** and sign in with Google (it is free).
2. Click **Create API Key**, name it `PulseAgent`, and copy the key (`gsk_...`).
3. Go to **Tab A (`http://localhost:8000/setup`) → Step 2 (AI Brain & n8n Sync)**:
   - Click the button **`Preset: Groq Free/Fast (Llama 3.3 70B)`** *(this fills the URL and model automatically!)*.
   - Paste your `gsk_...` key into **LLM API Key**.
   - Click **🧪 Test Live LLM Completion** → Wait 1 second → Badge turns **green (`✓ Verified Live`)**!

### Step 2.2 — Push All 4 Workflows into n8n in 1 Click (No Manual Wiring!)
1. Go to **Tab B (`http://localhost:5678`)** and create your local n8n login (email + password — this stays on your own machine).
2. In n8n, click the bottom-left gear icon **Settings → n8n API → Create an API key** → Copy the key.
3. Back in **Tab A (`/setup` → Step 2)** under the **n8n** card:
   - Set **n8n Base URL** to `http://n8n:5678` *(because inside Docker, the two containers talk via `http://n8n:5678`)*.
   - Paste your **n8n API Key**.
   - Click the green button **🚀 Auto-Push All 4 Workflows to n8n**!
4. Refresh **Tab B (`http://localhost:5678`)** → All 4 workflows (`01` through `04`) are now sitting on your n8n dashboard! Toggle the switch on the top right of each workflow to **Active** when you are ready for autopilot.

---

## 🌐 PHASE 3: Give Instagram & TikTok a Public Link to Grab Your Videos (3 Minutes)

YouTube lets you upload video files directly, **but Instagram and TikTok require a public `https://` link** to pull your rendered `.mp4` video.
- **If running on your own laptop:** Install free Cloudflare Tunnel (`winget install Cloudflare.cloudflared` on Windows or `brew install cloudflare/cloudflare/cloudflared` on Mac) and run:
  ```bash
  cloudflared tunnel --url http://localhost:8000
  ```
- Copy the `https://xxxx-xxxx.trycloudflare.com` link it prints, paste it into **`/setup` → Step 1 → Public HTTPS Media URL** (and **Public Dashboard URL**), and click **💾 Save All Settings**.

---

## 📱 PHASE 4: Connect Your Social Channels (`Step 3` on `/setup`)

> **💡 Beginner Golden Rule:** Connect **YouTube Shorts FIRST**, test 1 auto-post, then connect **Instagram**, then **TikTok**. Never rush all 3 in the same minute!

### 4A. YouTube Shorts (1-Click Google Sign-In)
1. Go to **[console.cloud.google.com](https://console.cloud.google.com/)** → Create a New Project called `ViralAgent`.
2. Search the top bar for **YouTube Data API v3** → Click **Enable**.
3. Go to **APIs & Services → OAuth consent screen** → Choose **External**, enter your email, and under **Test users**, add your own YouTube Gmail address!
4. Go to **Credentials → + Create Credentials → OAuth client ID → Web application**:
   - On `/setup` → **Step 3**, click **Copy URI** next to `Authorized Google Redirect URI`.
   - Paste that URI under **Authorized redirect URIs** in Google Cloud and click **Create**.
5. Copy the **Client ID** and **Client Secret** into `/setup` → **Step 3 (YouTube card)**, and click **🔗 Connect YouTube via Google OAuth2**. Sign into your YouTube channel, click Allow, and it will redirect back with **`✓ Verified Live`**!
6. *(Optional)* In Google Cloud **Credentials → + Create Credentials → API key**, copy the `AIzaSy...` key into **YouTube Data API Key** so Workflow 01 can scan YouTube's trending chart.

### 4B. Instagram Reels & Stories
1. On your phone's Instagram app: **Settings → Account type and tools → Switch to professional account (Creator or Business)** and link it to a Facebook Page.
2. Go to **[developers.facebook.com/apps](https://developers.facebook.com/apps)** → **Create App → Business**.
3. Open **Tools → Graph API Explorer**, select your App, add permissions `instagram_basic`, `instagram_content_publish`, `pages_show_list`, `pages_read_engagement`, and click **Generate Access Token**.
4. In the Graph Explorer query bar, type `me/accounts?fields=instagram_business_account{id,username}` and hit Submit → Copy your numeric `id` (`178414...`).
5. Paste the **Instagram Business User ID**, **Access Token**, **App ID**, and **App Secret** into `/setup` → **Step 3 (Instagram card)** and click **🔄 Exchange 60-Day Token & Verify**.

### 4C. TikTok Feed & Stories
1. Go to **[developers.tiktok.com](https://developers.tiktok.com/)** → **Manage Apps → Connect an App**.
2. Enable **Login Kit** and **Content Posting API** (`video.publish`, `video.upload`).
3. Copy the **Authorized TikTok Redirect URI** from `/setup` → **Step 3** into TikTok's Redirect URI box.
4. Paste your **Client Key** and **Client Secret** into `/setup` → **Step 3** and click **🔗 Connect TikTok OAuth2**.

---

## 🛍️ PHASE 5: Connect Your E-Commerce Stores (`Step 4` on `/setup`)

> **🎼 Composer’s Advice for Beginners (Crucial!):**  
> Start with **Shopify first**! Shopify gives you an API key in **60 seconds** with zero paperwork. Once your Shopify store + viral product ad videos are running smoothly, add **TikTok Shop** second, and **Amazon Seller Central** third (Amazon requires developer tax/identity verification that takes a few days). **Your agent already works even if only 1 store is connected!**

### 5A. Shopify Store (Takes 60 Seconds — Start Here!)
1. Open your Shopify Admin (`your-store.myshopify.com/admin`).
2. Click **Settings** (bottom left) → **Apps and sales channels → Develop apps → Allow custom app development → Create an app** (name it `PulseAgent`).
3. Click **Configure Admin API scopes** and tick these 4 boxes:
   - `write_products` & `read_products`
   - `read_orders`
   - `write_inventory`
4. Click **Save → Install app → Reveal token once** → Copy the `shpat_...` token.
5. Paste `your-store.myshopify.com` and `shpat_...` into `/setup` → **Step 4 (Shopify card)** and click **🧪 Verify Shopify Store**.

### 5B. TikTok Shop & Amazon SP-API (Add Whenever Ready)
- **TikTok Shop:** In **[partner.tiktokshop.com](https://partner.tiktokshop.com/)**, create an In-House Seller App → paste `App Key`, `App Secret`, and `Access Token` into Step 4 → click **Verify** *(our Setup page automatically calculates the cryptographic signature and fetches your `Shop Cipher` for you!)*.
- **Amazon Seller Central:** Once approved for **SP-API** under *Apps and Services → Develop Apps*, click *Authorize* on your app to get your `Atzr|...` Refresh Token → paste `Seller ID`, `LWA Client ID`, `LWA Client Secret`, and `Refresh Token` into Step 4 → click **Verify**.

---

## 📲 PHASE 6: Turn On Daily WhatsApp & Email Alerts (`Step 5` on `/setup`)

### 6A. Email Digest (Takes 60 Seconds via Resend — Free!)
1. Go to **[resend.com](https://resend.com/)**, sign up free, click **API Keys → Create API Key**, and copy `re_...`.
2. In `/setup` → **Step 5 (Email card)**:
   - Enter your personal email in **Send Daily Reports To**.
   - Set **From Address** to `onboarding@resend.dev` *(works immediately without buying a domain!)*.
   - Paste `re_...` into **Resend API Key** and click **✉️ Send Real Test Email** → Check your inbox!

### 6B. WhatsApp Alerts (Free via Meta Cloud API)
1. Inside the same **[developers.facebook.com](https://developers.facebook.com/)** app you made in Phase 4B, click **Add Product → WhatsApp → API Setup**.
2. Copy the **Phone number ID** and **Temporary/System Access Token**, enter your own WhatsApp phone number (`+236...`), and click **📲 Send Real Test WhatsApp** → Your phone will buzz within 2 seconds!

---

## ✍️ PHASE 7: Where Are the Prompts? (And How to Customize Your Niche!)

You asked *"when to go and paste with prompt"* — **all default prompts are already pre-installed**, so you don't *have* to paste anything!  
However, if you want to **change your channel's style or product niche**, here is the exact place to click:

1. Open **n8n (`http://localhost:5678`)** and click **`01 - Viral AI Animated Shorts Autopilot`**.
2. Double-click the box named **`AI Trend Analyzer & Viral Scriptwriter`**.
3. Inside `JSON Body`, you will see `"content": "You are an elite viral short-form animation director..."`. Swap that sentence with any of these **3 Proven Viral Niche Prompts**:

#### 🎨 Prompt Option A: 3D Pixar-Style Emotional Micro-Stories *(Default — Highest Retention)*
```text
You are an elite viral short-form animation director. Write an emotional 3D Pixar-style micro-story with a shocking 2-second curiosity hook and a heartwarming twist ending. Return JSON with keys: style_id ('pixar_micro_lore'), title (max 55 chars), lil_viral_description (max 95 chars curiosity question + 2 emojis), hashtags (5 tags starting with #shorts #aianimation), voiceover_script (40-50 words, 6th-grade reading level, ends in a seamless loop), scene_prompts (array of 4 detailed vertical 9:16 3D Pixar-style scene descriptions with NO text in image), voice ('en-US-ChristopherNeural').
```

#### 🧠 Prompt Option B: Dark Psychology / Stoic Anime Facts *(Fastest Subscriber Growth)*
```text
You are a viral psychology & mindset Shorts creator. Pick 1 fascinating human psychology effect (like the Zeigarnik Effect or Spotlight Effect) and explain it as a dramatic cyberpunk anime story in 45 words. Return JSON with keys: style_id ('dark_stoic_anime'), title (max 55 chars), lil_viral_description (max 95 chars hook), hashtags (['#shorts','#psychologyfacts','#mindset','#animeedit','#viral']), voiceover_script (40-50 words starting with 'Did you know your brain secretly...'), scene_prompts (4 vertical 9:16 cinematic Makoto Shinkai neon anime scenes, no text), voice ('en-US-GuyNeural').
```

#### 🌍 Prompt Option C: "What If / Untold History" Miniature Worlds *(High Shareability)*
```text
You are a viral 'What If & Untold Mysteries' narrator. Tell a mind-blowing true bizarre historical or science event in 45 words. Return JSON with keys: style_id ('cozy_isometric_worlds'), title (max 55 chars), lil_viral_description (max 95 chars curiosity hook), hashtags (['#shorts','#didyouknow','#historyfacts','#weirdhistory','#fyp']), voiceover_script (42-50 words starting with an unbelievable hook), scene_prompts (4 vertical 9:16 ultra-detailed tilt-shift miniature diorama scenes, no text), voice ('en-US-AriaNeural').
```

---

## ⚡ PHASE 8: Your 5-Minute Daily Routine for Maximum Efficiency

Once setup is saved (`💾 Save All Settings` on `/setup`), here is how you run this like a pro without burnout or account bans:

1. **Let Animated Shorts Run Automatically (3x/day):** Workflow 01 creates, voices, captions, waits for peak engagement hours (12 PM / 7 PM / 9 PM), and posts your AI Animated Shorts automatically.
2. **Every Morning (2 Minutes):** Check your **WhatsApp / Email** alert at 07:05 AM. Click the link to open **Tab 3 (Viral Product Shortlist)** on your dashboard.
3. **Pick Only the Best Winner:** Look at the 3 shortlisted products. Ask two simple questions:
   - *Does this solve an instant visual problem in 3 seconds?*
   - *Is Gross Margin above 65%?*
4. **1-Click Launch:** Click **🚀 Approve & Publish** on your favorite pick. Your agent automatically creates the product page on your store(s), renders both the **9:16 Reel/Shorts Ad** and **15s Story Ad**, and schedules them across YT Shorts, IG Reels/Stories, and TikTok!
5. **Every Evening (8:00 PM):** Read your **30-second WhatsApp Daily Digest** to track total videos posted and live store products.
