# PulseAgent — n8n + Budget FFmpeg Viral Shorts & Omnichannel E-Commerce Agent

A complete, self-hosted **Hybrid Autonomous AI Agent** combining **4 importable n8n low-code workflows** with a **zero-cost FFmpeg AI Video & Product Ad Render Worker** and a **Web Approval & Command Dashboard**.

---

## 🏗️ System Architecture & Your Selected Stack

| Setting | Your Configuration | How It Works |
| :--- | :--- | :--- |
| **Orchestration** | **n8n Low-Code Workflows** | 4 visual JSON workflows (`n8n-workflows/*.json`) handle cron schedules, trend APIs, wait timers, multi-platform publishing, and daily notifications. |
| **Video & Ad Stack** | **Bootstrapped FFmpeg + Neural TTS** | `worker/ffmpeg_renderer.py` fetches free 9:16 Flux AI scenes (Pollinations / custom API), synthesizes free Microsoft Neural voiceovers (`edge-tts`), animates dynamic camera motion (`zoompan`), adds ambient background music, and burns in kinetic pop-in `.ass` captions (~**$0.00–$0.01 per video**!). |
| **Autonomy Mode** | **Hybrid Autonomy** | **Animated Shorts** run 100% on Autopilot (Trend → Render → Best Timeline Wait → Post to YT Shorts, TikTok & IG Reels). **Viral Store Products** pause in your Web Approval Queue until you click **Approve & Launch**. |
| **Notifications** | **Web Dashboard + WhatsApp + Email** | Instant shortlist alerts & evening **Daily Digest** via **Meta WhatsApp Cloud API** + **HTML Email (Resend / SMTP)** + real-time browser hub. |

---

## 📂 Included Files

```text
viral-commerce-agent/
├── docker-compose.yml                                      # Runs n8n (:5678) + Agent Hub & FFmpeg Worker (:8000)
├── Dockerfile                                              # Python + FFmpeg + libass + edge-tts container
├── .env.example                                            # All API keys & credentials template
├── server.py                                               # Web Dashboard + REST API endpoints called by n8n
├── static/index.html                                       # Live Command Center, Video Studio & 1-Click Product Approval UI
├── n8n-workflows/
│   ├── 01_viral_animated_shorts_autopilot.json             # 8h Trend -> Script -> FFmpeg Short -> Wait -> YT/TikTok/IG
│   ├── 02_viral_product_discovery_shortlist.json           # Daily Shopify + Amazon + TikTok Trend -> Score -> Approval Queue
│   ├── 03_store_publisher_and_product_ads.json             # Approval Webhook -> Shopify/Amazon/TikTok Shop + Reel & Story Ads
│   └── 04_daily_whatsapp_email_digest.json                 # Daily 20:00 PM WhatsApp Cloud API + HTML Email Report
└── worker/
    ├── ffmpeg_renderer.py                                  # 9:16 Ken Burns + edge-tts + ASS Hormozi caption video engine
    ├── platform_connectors.py                              # Shopify, Amazon SP-API, TikTok Shop (HMAC), WhatsApp & Email clients
    └── trend_scoring.py                                    # Viral style velocity, peak posting timeline & 100-pt product scorer
```

---

## 🚀 Quick Start (Docker Compose — Local or $6/mo VPS)

### 1. Configure Environment Variables
```bash
cd viral-commerce-agent
cp .env.example .env
```
> **Tip:** You can start immediately **without** filling in live store keys! Any platform without keys automatically runs in **Sandbox Mode**, generating realistic receipts and real `.mp4` videos so you can test the entire pipeline safely first.

### 2. Launch n8n + FFmpeg Agent Hub
```bash
docker compose up -d --build
```
- **Web Command & Approval Dashboard:** `http://localhost:8000`
- **n8n Visual Workflow Editor:** `http://localhost:5678`

### 3. Import the 4 n8n Workflows
1. Open `http://localhost:5678` and create your local n8n owner account.
2. Go to **Workflows → Add Workflow → `...` (top right) → Import from File**.
3. Import each file inside `n8n-workflows/` in order (`01` through `04`) and toggle **Active** in the top-right corner.
4. Notice that inside Docker Compose, n8n reaches the FFmpeg worker automatically via `http://agent-hub:8000`.

---

## 🔑 Platform API Setup & Important Real-World Rules

### 1. Public HTTPS URL for Instagram & TikTok Video Pulls
Instagram Graph API and TikTok Content Posting API download your `.mp4` from a public HTTPS URL (`PUBLIC_MEDIA_BASE_URL`).
- On a VPS with a domain, point `media.yourdomain.com` to port `8000` (via Caddy/Nginx or free **Cloudflare Tunnel** `cloudflared tunnel --url http://localhost:8000`).

### 2. YouTube Shorts (`YOUTUBE_OAUTH_ACCESS_TOKEN`)
- Create a project in **Google Cloud Console** → Enable **YouTube Data API v3**.
- Connect your YouTube OAuth2 credential in n8n (`youtube.upload` scope).
- Any vertical `9:16` video under 60 seconds with `#Shorts` in the title/description is automatically indexed on the YouTube Shorts feed.

### 3. Instagram Reels & Stories (`META_GRAPH_ACCESS_TOKEN`)
- Switch your Instagram account to a **Professional (Business or Creator)** account and link it to a Facebook Page.
- In **Meta for Developers**, create a Business App with `instagram_basic` and `instagram_content_publish`.
- Workflow 01 & 03 natively publish both **Reels** (`media_type=REELS`) and **15-second Stories** (`media_type=STORIES`).

### 4. TikTok Feed & Stories (`TIKTOK_ACCESS_TOKEN`)
- Register at **TikTok for Developers** → Add **Content Posting API** (`video.publish`, `video.upload`).
- **Feed/Reels:** Uses `/v2/post/publish/video/init/` (`DIRECT_POST`).
- **Stories Note:** TikTok restricts unmanned Story-only auto-publishing until your app passes audit; Workflow 03 uses `/v2/post/publish/inbox/video/init/` so the 15s Story cut lands directly in your TikTok app notification inbox for a 1-tap Story post!

### 5. Shopify, Amazon SP-API & TikTok Shop
- **Shopify:** Store Admin → *Settings → Apps and sales channels → Develop apps* → grant `write_products`, `read_orders`, `write_inventory` → copy `shpat_...` token.
- **Amazon SP-API:** Register as a Developer in **Amazon Seller Central** → create an SP-API app to obtain `LWA Client ID`, `LWA Client Secret`, and `Refresh Token`.
- **TikTok Shop:** Register in **TikTok Shop Partner Center** → create an in-house seller app to get `App Key`, `App Secret`, and `Shop Cipher`. `worker/platform_connectors.py` handles the required **HMAC-SHA256** request signing automatically!

### 6. Daily WhatsApp & Email Notifications
- **WhatsApp:** In the same **Meta for Developers** app you created for Instagram, add the **WhatsApp** product → copy the free `Phone Number ID` and `Access Token` into `.env`.
- **Email:** Add a free **Resend.com** API key (3,000 free emails/month) or Gmail App Password SMTP credentials.

---

## 💰 Estimated Monthly Operating Cost (Bootstrapped Stack)

| Component | Provider | Est. Cost (90 Shorts + 30 Product Ads / mo) |
| :--- | :--- | :--- |
| **n8n + FFmpeg Worker Hosting** | Self-hosted Docker on 2 vCPU VPS | **$5 – $8 / mo** |
| **Voiceover Synthesis** | `edge-tts` Neural Voices | **$0.00** |
| **9:16 AI Scene Artwork** | Pollinations Flux (or Together Flux-Schnell) | **$0.00 – $1.50 / mo** |
| **Motion, Subtitles & Editing** | Local `ffmpeg` (`zoompan` + `libass`) | **$0.00** |
| **Trend & Copywriting LLM** | `gpt-4o-mini` / Groq Llama-3.3 | **~$0.60 / mo** |
| **WhatsApp + Email Digests** | Meta Cloud API (Service/Utility) + Resend Free Tier | **$0.00** |
| **Total Monthly AI Infrastructure** | | **~$6 – $10 / month total** |
