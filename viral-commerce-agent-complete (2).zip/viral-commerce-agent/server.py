#!/usr/bin/env python3
"""
Viral Commerce & AI Shorts Agent Hub (Web Dashboard + Live Setup Wizard + n8n Companion API)
--------------------------------------------------------------------------------------------
Binds to 0.0.0.0:8000 using pre-installed `aiohttp`.
Provides:
1. Live Browser Command & Approval Dashboard (`/`)
2. Genuine End-to-End Setup & Live Integrations Page (`/setup`)
3. Live Connection Verification, OAuth2 Flows & 1-Click n8n Workflow Auto-Deployer (`/api/setup/*`, `/api/oauth/*`)
4. FFmpeg Budget Video Render Endpoints (`/api/render/short`, `/api/render/product-ad`)
5. Product Shortlist & 1-Click Omnichannel Approval (`/api/products/*`)
6. Daily Digest Notification API for WhatsApp + Email (`/api/summary/daily`, `/api/notifications/send-daily`)
"""

import asyncio
import json
import os
import time
import urllib.parse
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict

import httpx
from aiohttp import web

from worker.config_manager import (
    ENV_FILE,
    get_masked_settings_for_ui,
    load_raw_settings,
    update_settings_from_ui,
)
from worker.connection_testers import (
    build_oauth_start_url,
    exchange_oauth_callback,
    test_amazon,
    test_email,
    test_ffmpeg_tts,
    test_instagram,
    test_llm,
    test_or_deploy_n8n,
    test_shopify,
    test_tiktok,
    test_tiktok_shop,
    test_whatsapp,
    test_youtube,
)
from worker.ffmpeg_renderer import render_vertical_video
from worker.platform_connectors import (
    publish_to_amazon_sp_api,
    publish_to_shopify,
    publish_to_tiktok_shop,
    send_daily_notifications,
)
from worker.trend_scoring import (
    TRENDING_ANIMATION_STYLES,
    compute_best_publish_timeline,
    score_product_candidate,
)

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
STATIC_DIR = BASE_DIR / "static"
MEDIA_DIR = BASE_DIR / "media"
WORKFLOWS_DIR = BASE_DIR / "n8n-workflows"
STATE_FILE = DATA_DIR / "agent_state.json"

DATA_DIR.mkdir(parents=True, exist_ok=True)


def _tz_offset() -> int:
    cfg = load_raw_settings()
    try:
        return int(float(cfg.get("AUDIENCE_TZ_OFFSET_HOURS", "1")))
    except ValueError:
        return 1


def _resolution_dims() -> tuple:
    cfg = load_raw_settings()
    res = cfg.get("VIDEO_RESOLUTION", "720x1280")
    if "1080" in res:
        return 1080, 1920
    return 720, 1280


def _public_origin(request: web.Request) -> str:
    proto = request.headers.get("X-Forwarded-Proto", request.scheme)
    host = request.headers.get("X-Forwarded-Host", request.host)
    return f"{proto}://{host}"


def _initial_state() -> Dict:
    schedule = compute_best_publish_timeline(tz_offset_hours=_tz_offset())
    products_raw = [
        {
            "id": "prod_maglev_moon",
            "sku": "VCA-MAGLEV-MOON-01",
            "title": "MagLev Galaxy Floating Moon Lamp & 15W Wireless Desk Charger",
            "category": "Smart Home & Desk Decor",
            "brand": "TrendPulse Studio",
            "thumbnail": "/media/scenes/ad_scene_1.jpg",
            "scene_paths": ["media/scenes/ad_scene_1.jpg", "media/scenes/ad_scene_2.jpg"],
            "supplier_cost_usd": 11.80,
            "recommended_price_usd": 44.99,
            "compare_at_price_usd": 74.99,
            "demand_velocity": 97,
            "video_wow_score": 98,
            "fulfillment_ease": 90,
            "trend_sources": [
                "TikTok #TikTokMadeMeBuyIt (+410% 7d views)",
                "Amazon Movers & Shakers #4 Lighting",
                "Shopify Home Office Niche Top Converter",
            ],
            "lil_viral_description": "Wait… how is this moon floating in mid-air while charging my phone?! 😱✨",
            "hashtags": ["#tiktokmademebuyit", "#desksetup", "#coolgadgets", "#roomdecor", "#shorts"],
            "cta_banner": "40% OFF TODAY • LINK IN BIO",
            "ad_hook_script": "Stop buying boring desk lamps! This levitating galaxy moon floats in mid air using magnetic suspension while fast charging your phone wirelessly.",
            "story_ad_script": "Wait is that moon actually floating? Magnetic levitation plus wireless fast charging on your nightstand. Tap the link before we sell out!",
            "store_html_description": "<p><strong>Transform any nightstand or desk into a zero-gravity sanctuary.</strong> Engineered with silent electromagnetic suspension and a solid walnut 15W Qi fast-charging base.</p><ul><li>360° frictionless mid-air rotation</li><li>3 warm-to-lunar touch lighting modes</li><li>Built-in 15W fast wireless phone pad</li></ul>",
            "amazon_description": "Levitating 3D-printed galaxy moon lamp with electromagnetic floating walnut wood base and integrated 15W Qi fast wireless smartphone charger.",
            "bullet_points": [
                "TRUE MAGNETIC LEVITATION: Floats and spins silently 15mm above the solid walnut base.",
                "2-IN-1 15W QI WIRELESS CHARGER: Fast-charge iPhone, Galaxy, or AirPods right on the base.",
                "NASA TOPOGRAPHY 3D SHELL: High-resolution crater texture with warm amber, ivory, and nebula glow.",
                "SAFE POWER-OFF PROTECTION: Magnetic core safely catches the moon if power is unplugged.",
                "VIRAL GIFT READY BOX: Ships in premium gift packaging with braided USB-C power adapter.",
            ],
            "approval_status": "pending_approval",
            "reel_ad_video": "/media/renders/sample_product_ad.mp4",
            "story_ad_video": "/media/renders/sample_product_story.mp4",
            "store_receipts": {},
            "ad_deployments": [],
        },
        {
            "id": "prod_aerochill_neck",
            "sku": "VCA-AEROCHILL-PRO-02",
            "title": "AeroChill Pro Bladeless Semiconductor Cooling Neck AC",
            "category": "Wearable Cooling Tech",
            "brand": "TrendPulse Studio",
            "thumbnail": "/media/scenes/prod_neck_fan.jpg",
            "scene_paths": ["media/scenes/prod_neck_fan.jpg"],
            "supplier_cost_usd": 14.20,
            "recommended_price_usd": 49.99,
            "compare_at_price_usd": 79.99,
            "demand_velocity": 94,
            "video_wow_score": 91,
            "fulfillment_ease": 91,
            "trend_sources": [
                "Amazon Movers & Shakers #2 Portable Fans (+320% sales rank)",
                "TikTok Shop Trending Summer/Travel Tech",
            ],
            "lil_viral_description": "Personal air conditioning around your neck that drops skin temp by 16°F in 3 seconds ❄️🔥",
            "hashtags": ["#travelhacks", "#coolgadgets", "#summeressentials", "#amazonfinds", "#shorts"],
            "cta_banner": "FLASH DEAL $49.99 • SHOP NOW",
            "ad_hook_script": "Sweating through your commute? This bladeless titanium neck cooler uses dual Peltier cooling plates to drop skin temperature in three seconds flat.",
            "story_ad_script": "Instant icy air around your neck with zero hair tangles and 12 hour USB-C battery. Tap to grab 35% off!",
            "store_html_description": "<p><strong>Beat extreme heat hands-free.</strong> Dual semiconductor cooling plates + 360° hair-safe bladeless vents deliver instant wearable climate control.</p>",
            "amazon_description": "Bladeless wearable neck air conditioner with semiconductor cooling plate, LED battery display, and 5000mAh USB-C rechargeable battery.",
            "bullet_points": [
                "INSTANT PELTIER COOLING PLATE: Chills skin in 3 seconds with whisper-quiet 28dB airflow.",
                "100% HAIR-SAFE BLADELESS TURBINES: Zero tangles for long hair during workouts or travel.",
                "SMART LED DIGITAL DISPLAY: Real-time temperature mode and battery percentage readout.",
                "ALL-DAY 5000mAh USB-C BATTERY: Up to 12 hours of continuous cooling on Eco mode.",
                "FEATHERLIGHT ERGONOMIC FIT: Brushed titanium flex collar weighs just 295g.",
            ],
            "approval_status": "pending_approval",
            "reel_ad_video": None,
            "story_ad_video": None,
            "store_receipts": {},
            "ad_deployments": [],
        },
        {
            "id": "prod_cremago_espresso",
            "sku": "VCA-CREMAGO-20BAR-03",
            "title": "CremaGo Pocket 20-Bar Self-Heating USB-C Portable Espresso Maker",
            "category": "Coffee & Everyday Carry",
            "brand": "TrendPulse Studio",
            "thumbnail": "/media/scenes/prod_espresso.jpg",
            "scene_paths": ["media/scenes/prod_espresso.jpg"],
            "supplier_cost_usd": 18.50,
            "recommended_price_usd": 64.99,
            "compare_at_price_usd": 99.00,
            "demand_velocity": 92,
            "video_wow_score": 95,
            "fulfillment_ease": 86,
            "trend_sources": [
                "TikTok #CoffeeTok Viral Demo (14.2M niche views this week)",
                "Shopify High-AOV Impulse Gift Winner",
            ],
            "lil_viral_description": "Barista-grade golden crema espresso in your car, camp, or desk—no kettle needed ☕✨",
            "hashtags": ["#coffeetok", "#espresso", "#campinggear", "#tiktokmademebuyit", "#shorts"],
            "cta_banner": "SAVE $34 TODAY • FREE SHIPPING",
            "ad_hook_script": "Stop paying seven dollars for burnt coffee! Pour cold water into this pocket espresso machine and watch twenty bars of pressure pull rich golden crema anywhere.",
            "story_ad_script": "Cold water in, steaming 20-bar golden crema espresso out in 180 seconds. Works with grounds or pods—tap link in bio!",
            "store_html_description": "<p><strong>Real 20-bar Italian-style crema anywhere on Earth.</strong> Heats cold water to 92°C automatically via built-in 7500mAh USB-C battery.</p>",
            "amazon_description": "Portable self-heating 20-bar electric espresso machine compatible with ground coffee and NS capsules, USB-C rechargeable for travel, car, and camping.",
            "bullet_points": [
                "SELF-HEATING TO 92°C (198°F): Add cold water and brew piping hot espresso in 3 minutes.",
                "20-BAR HIGH-PRESSURE EXTRACTION: Produces thick, velvety golden crema on every shot.",
                "2-IN-1 CAPSULE & GROUND COFFEE ADAPTER: Brew your favorite roast or Nespresso-style pods.",
                "7500mAh USB-C POWER BANK BATTERY: Pulls up to 5 hot shots from cold water or 40+ with hot water.",
                "LEAKPROOF STAINLESS CHAMBER: Rinses clean in 10 seconds under any tap.",
            ],
            "approval_status": "pending_approval",
            "reel_ad_video": None,
            "story_ad_video": None,
            "store_receipts": {},
            "ad_deployments": [],
        },
    ]

    scored_products = [score_product_candidate(p) for p in products_raw]

    return {
        "autonomy_config": {
            "mode": "hybrid_autonomy",
            "animated_shorts": "auto_publish",
            "store_products": "require_approval",
            "video_stack": "budget_ffmpeg_edge_tts",
            "notification_channels": ["web_dashboard", "whatsapp_cloud_api", "email_digest"],
        },
        "shorts_queue": [
            {
                "id": "short_clockwork_seed",
                "title": "The Last Living Seed in Neon City",
                "style_name": "3D Stylized Micro-SciFi / Pixar Lore",
                "lil_viral_description": "Everyone sold their memories for battery power… until he found what they hid 🤖🌱",
                "hashtags": ["#shorts", "#aianimation", "#scifistories", "#pixarstyle", "#viralstory"],
                "script_text": "In a city where every memory was sold for battery power, one tiny clockwork robot found the last living seed on Earth, and sparked a neon revolution.",
                "video_url": "/media/renders/sample_animated_short.mp4",
                "duration_sec": 9.14,
                "status": "scheduled_autopilot",
                "platforms": ["youtube_shorts", "tiktok", "instagram_reels"],
                "schedule": schedule,
                "created_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
            }
        ],
        "products": scored_products,
        "notification_logs": [
            {
                "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
                "type": "Daily Shortlist Ready",
                "channels": ["Web Dashboard", "WhatsApp Preview", "Email Digest"],
                "summary": "3 viral high-margin products shortlisted from Amazon Movers & TikTok Creative Center; 1 AI Animated Short queued for peak evening timeline.",
            }
        ],
    }


def load_state() -> Dict:
    if not STATE_FILE.exists():
        state = _initial_state()
        save_state(state)
        return state
    return json.loads(STATE_FILE.read_text(encoding="utf-8"))


def save_state(state: Dict) -> None:
    STATE_FILE.write_text(json.dumps(state, indent=2), encoding="utf-8")


@web.middleware
async def cors_and_security_middleware(request: web.Request, handler):
    if request.method == "OPTIONS":
        resp = web.Response(status=204)
    else:
        resp = await handler(request)
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, PATCH, PUT, DELETE, OPTIONS"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization, X-Agent-Secret"
    resp.headers.pop("X-Frame-Options", None)
    return resp


async def handle_index(request: web.Request) -> web.FileResponse:
    return web.FileResponse(STATIC_DIR / "index.html")


async def handle_setup_page(request: web.Request) -> web.FileResponse:
    return web.FileResponse(STATIC_DIR / "setup.html")


# ---------------------------------------------------------------------------
# GENUINE SETUP, LIVE CONNECTION VERIFICATION & OAUTH2 ENDPOINTS
# ---------------------------------------------------------------------------
async def handle_get_setup_config(request: web.Request) -> web.Response:
    origin = _public_origin(request)
    payload = get_masked_settings_for_ui()
    payload["oauth_redirect_uris"] = {
        "youtube": f"{origin}/api/oauth/youtube/callback",
        "tiktok": f"{origin}/api/oauth/tiktok/callback",
        "shopify": f"{origin}/api/oauth/shopify/callback",
    }
    payload["detected_origin"] = origin
    return web.json_response(payload)


async def handle_save_setup_config(request: web.Request) -> web.Response:
    body = await request.json()
    updated_raw = update_settings_from_ui(body)

    # Sync autonomy mode & brand rules into active dashboard state
    state = load_state()
    mode = updated_raw.get("AUTONOMY_MODE", "hybrid_autonomy")
    state["autonomy_config"]["mode"] = mode
    state["autonomy_config"]["animated_shorts"] = (
        "require_approval" if mode == "approval_queue" else "auto_publish"
    )
    state["autonomy_config"]["store_products"] = (
        "auto_publish" if mode == "full_autopilot" else "require_approval"
    )
    state["notification_logs"].insert(
        0,
        {
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
            "type": "Setup Configuration Updated",
            "channels": ["Runtime Engine", ".env Synced"],
            "summary": f"Saved live configuration (Autonomy: {mode}, Timezone: {updated_raw.get('AGENT_TIMEZONE')}, Voice: {updated_raw.get('DEFAULT_VOICE')}).",
        },
    )
    save_state(state)

    resp = get_masked_settings_for_ui()
    resp["saved"] = True
    return web.json_response(resp)


async def handle_test_provider(request: web.Request) -> web.Response:
    provider = request.match_info["provider"]
    try:
        body = await request.json()
    except Exception:
        body = {}

    # Allow saving inline form edits before running the live test!
    if isinstance(body.get("settings"), dict):
        update_settings_from_ui(body["settings"])

    send_ping = bool(body.get("send_ping", False))
    exchange_ll = bool(body.get("exchange_long_lived", False))

    testers = {
        "ffmpeg_tts": lambda: test_ffmpeg_tts(),
        "llm": lambda: test_llm(),
        "shopify": lambda: test_shopify(),
        "amazon": lambda: test_amazon(),
        "tiktok_shop": lambda: test_tiktok_shop(),
        "youtube": lambda: test_youtube(),
        "instagram": lambda: test_instagram(exchange_long_lived=exchange_ll),
        "tiktok": lambda: test_tiktok(),
        "whatsapp": lambda: test_whatsapp(send_ping=send_ping),
        "email": lambda: test_email(send_ping=send_ping),
        "n8n": lambda: test_or_deploy_n8n(deploy_workflows=False),
    }
    if provider not in testers:
        return web.json_response({"ok": False, "message": f"Unknown provider '{provider}'"}, status=400)

    result = await testers[provider]()
    ui_state = get_masked_settings_for_ui()
    return web.json_response({"result": result, "readiness": ui_state["readiness"], "values": ui_state["values"]})


async def handle_deploy_n8n(request: web.Request) -> web.Response:
    try:
        body = await request.json()
        if isinstance(body.get("settings"), dict):
            update_settings_from_ui(body["settings"])
    except Exception:
        pass
    result = await test_or_deploy_n8n(deploy_workflows=True)
    ui_state = get_masked_settings_for_ui()
    return web.json_response({"result": result, "readiness": ui_state["readiness"]})


async def handle_export_env(request: web.Request) -> web.Response:
    load_raw_settings()
    content = ENV_FILE.read_bytes() if ENV_FILE.exists() else b""
    return web.Response(
        body=content,
        content_type="text/plain",
        headers={"Content-Disposition": 'attachment; filename=".env"'},
    )


async def handle_download_project_zip(request: web.Request) -> web.Response:
    zip_path = BASE_DIR.parent / "viral-commerce-agent-complete.zip"
    if not zip_path.exists():
        return web.json_response({"error": "Project zip archive not found"}, status=404)
    return web.FileResponse(
        zip_path,
        headers={"Content-Disposition": 'attachment; filename="viral-commerce-agent-complete.zip"'},
    )


async def handle_runtime_config_for_n8n(request: web.Request) -> web.Response:
    """Allows local n8n containers to dynamically read non-hardcoded runtime rules."""
    cfg = load_raw_settings()
    secret = cfg.get("AGENT_INTERNAL_SECRET", "").strip()
    if secret and request.headers.get("X-Agent-Secret", "") != secret:
        return web.json_response({"error": "Unauthorized: invalid X-Agent-Secret"}, status=401)
    return web.json_response(
        {
            "autonomy_mode": cfg.get("AUTONOMY_MODE"),
            "timezone": cfg.get("AGENT_TIMEZONE"),
            "tz_offset_hours": _tz_offset(),
            "shorts_per_day": int(cfg.get("SHORTS_PER_DAY") or 3),
            "default_voice": cfg.get("DEFAULT_VOICE"),
            "min_product_margin_pct": float(cfg.get("MIN_PRODUCT_MARGIN_PCT") or 65),
            "store_brand_name": cfg.get("STORE_BRAND_NAME"),
            "default_cta_banner": cfg.get("DEFAULT_CTA_BANNER"),
            "llm_base_url": cfg.get("LLM_BASE_URL"),
            "llm_model": cfg.get("LLM_MODEL"),
        }
    )


async def handle_oauth_start(request: web.Request) -> web.Response:
    provider = request.match_info["provider"]
    ok, url_or_err = build_oauth_start_url(provider, _public_origin(request))
    if not ok:
        q = urllib.parse.urlencode({"oauth_error": url_or_err, "provider": provider})
        raise web.HTTPFound(f"/setup?{q}")
    raise web.HTTPFound(url_or_err)


async def handle_oauth_callback(request: web.Request) -> web.Response:
    provider = request.match_info["provider"]
    ok, msg = await exchange_oauth_callback(provider, dict(request.query), _public_origin(request))
    key = "oauth_success" if ok else "oauth_error"
    q = urllib.parse.urlencode({key: msg, "provider": provider})
    raise web.HTTPFound(f"/setup?{q}")


# ---------------------------------------------------------------------------
# CORE DASHBOARD, RENDERING & STORE APPROVAL ENDPOINTS
# ---------------------------------------------------------------------------
async def handle_get_state(request: web.Request) -> web.Response:
    state = load_state()
    state["optimal_timeline"] = compute_best_publish_timeline(tz_offset_hours=_tz_offset())
    state["trending_styles"] = TRENDING_ANIMATION_STYLES
    state["setup_readiness"] = get_masked_settings_for_ui()["readiness"]
    return web.json_response(state)


async def handle_trend_styles(request: web.Request) -> web.Response:
    return web.json_response(
        {
            "updated_at": datetime.now(timezone.utc).isoformat(),
            "trending_styles": TRENDING_ANIMATION_STYLES,
            "optimal_timeline": compute_best_publish_timeline(tz_offset_hours=_tz_offset()),
        }
    )


async def handle_tiktok_products(request: web.Request) -> web.Response:
    state = load_state()
    return web.json_response({"candidates": state["products"]})


async def handle_render_short(request: web.Request) -> web.Response:
    cfg = load_raw_settings()
    body = await request.json()
    title = (body.get("title") or "Untitled AI Short").strip()
    script_text = (
        body.get("script_text")
        or "Three hundred meters beneath the frozen ocean, an ancient glass station suddenly turned all its lights back on."
    ).strip()
    style_id = body.get("style_id", "pixar_micro_lore")
    style_obj = next((s for s in TRENDING_ANIMATION_STYLES if s["id"] == style_id), TRENDING_ANIMATION_STYLES[0])
    voice = body.get("voice") or cfg.get("DEFAULT_VOICE") or style_obj["voice"]
    lil_desc = (body.get("lil_viral_description") or f"{title} — wait for the twist at the end 👀✨").strip()
    hashtags = body.get("hashtags") or style_obj["top_hashtags"]

    scene_prompts = body.get("scene_prompts") or [
        f"{style_obj['visual_prompt_prefix']} {script_text[:95]}",
        f"{style_obj['visual_prompt_prefix']} dramatic climax wide shot, {title}",
    ]
    scene_paths = body.get("scene_paths")
    w, h = _resolution_dims()

    filename = f"short_{int(time.time())}.mp4"
    render_info = await render_vertical_video(
        output_filename=filename,
        script_text=script_text,
        scene_paths=scene_paths,
        scene_prompts=scene_prompts,
        voice=voice,
        width=w,
        height=h,
    )

    schedule = body.get("schedule") or compute_best_publish_timeline(tz_offset_hours=_tz_offset())
    mode = cfg.get("AUTONOMY_MODE", "hybrid_autonomy")
    short_status = "pending_review" if mode == "approval_queue" else "scheduled_autopilot"

    short_entry = {
        "id": f"short_{int(time.time())}",
        "title": title,
        "style_name": style_obj["name"],
        "lil_viral_description": lil_desc,
        "hashtags": hashtags,
        "script_text": script_text,
        "video_url": render_info["url"],
        "duration_sec": render_info["duration_sec"],
        "status": short_status,
        "platforms": ["youtube_shorts", "tiktok", "instagram_reels"],
        "schedule": schedule,
        "created_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
    }

    state = load_state()
    state["shorts_queue"].insert(0, short_entry)
    save_state(state)
    return web.json_response({**render_info, "short": short_entry})


async def _execute_product_launch(product: Dict, state: Dict) -> Dict:
    cfg = load_raw_settings()
    product["brand"] = cfg.get("STORE_BRAND_NAME") or product.get("brand", "TrendPulse Studio")
    w, h = _resolution_dims()
    ad_voice = cfg.get("DEFAULT_AD_VOICE") or "en-US-AriaNeural"
    default_cta = cfg.get("DEFAULT_CTA_BANNER") or "40% OFF TODAY • LINK IN BIO"

    shopify_res, amazon_res, tts_res = await asyncio.gather(
        publish_to_shopify(product),
        publish_to_amazon_sp_api(product),
        publish_to_tiktok_shop(product),
    )

    if not product.get("reel_ad_video"):
        reel_info = await render_vertical_video(
            output_filename=f"ad_reel_{product['id']}.mp4",
            script_text=product["ad_hook_script"],
            scene_paths=product.get("scene_paths", []),
            voice=ad_voice,
            cta_banner=product.get("cta_banner") or default_cta,
            width=w,
            height=h,
        )
        product["reel_ad_video"] = reel_info["url"]

    if not product.get("story_ad_video"):
        story_info = await render_vertical_video(
            output_filename=f"ad_story_{product['id']}.mp4",
            script_text=product["story_ad_script"],
            scene_paths=product.get("scene_paths", []),
            voice=ad_voice,
            cta_banner="TAP LINK TO SHOP",
            max_duration=12.0,
            width=w,
            height=h,
        )
        product["story_ad_video"] = story_info["url"]

    timeline = compute_best_publish_timeline(tz_offset_hours=_tz_offset())
    product["approval_status"] = "published_live"
    product["approved_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    product["store_receipts"] = {
        "shopify": shopify_res,
        "amazon": amazon_res,
        "tiktok_shop": tts_res,
    }
    product["ad_deployments"] = [
        {"surface": "YouTube Shorts", "asset": product["reel_ad_video"], "scheduled": timeline["youtube_shorts"]["display_time"], "status": "scheduled"},
        {"surface": "Instagram Reels", "asset": product["reel_ad_video"], "scheduled": timeline["instagram_reels"]["display_time"], "status": "scheduled"},
        {"surface": "Instagram Story (15s)", "asset": product["story_ad_video"], "scheduled": timeline["instagram_reels"]["display_time"], "status": "scheduled"},
        {"surface": "TikTok Feed / Reels", "asset": product["reel_ad_video"], "scheduled": timeline["tiktok"]["display_time"], "status": "scheduled"},
        {"surface": "TikTok Story (15s)", "asset": product["story_ad_video"], "scheduled": timeline["tiktok"]["display_time"], "status": "scheduled"},
    ]

    n8n_webhook = cfg.get("N8N_APPROVAL_WEBHOOK_URL", "").strip()
    if n8n_webhook:
        try:
            async with httpx.AsyncClient(timeout=8) as client:
                await client.post(n8n_webhook, json=product)
        except Exception:
            pass

    state["notification_logs"].insert(
        0,
        {
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
            "type": "Product Approved & Launched",
            "channels": ["Shopify", "Amazon SP-API", "TikTok Shop", "Shorts/Reels/Stories Ads"],
            "summary": f"Published '{product['title']}' ({shopify_res.get('mode')}) to all 3 stores and scheduled Reel + 15s Story ad cuts.",
        },
    )
    save_state(state)
    return product


async def handle_shortlist_product(request: web.Request) -> web.Response:
    cfg = load_raw_settings()
    body = await request.json()
    scored = score_product_candidate(body)
    scored.setdefault("id", f"prod_{int(time.time())}")
    scored.setdefault("approval_status", "pending_approval")

    min_margin = float(cfg.get("MIN_PRODUCT_MARGIN_PCT") or 65)
    state = load_state()
    state["products"].insert(0, scored)
    save_state(state)

    # Genuine Full Autopilot support if configured on /setup!
    if cfg.get("AUTONOMY_MODE") == "full_autopilot" and scored["gross_margin_pct"] >= min_margin:
        scored = await _execute_product_launch(scored, state)
        return web.json_response({"status": "autopilot_launched", "product": scored})

    return web.json_response({"status": "queued_for_approval", "product": scored})


async def handle_render_product_ad(request: web.Request) -> web.Response:
    cfg = load_raw_settings()
    body = await request.json()
    prod_id = body.get("product_id", f"prod_{int(time.time())}")
    ad_script = body.get("ad_script") or "Stop scrolling! Check out this viral gadget everyone is talking about right now."
    story_script = body.get("story_script") or ad_script
    cta_banner = body.get("cta_banner") or cfg.get("DEFAULT_CTA_BANNER") or "LIMITED OFFER • LINK IN BIO"
    scene_paths = body.get("scene_paths") or []
    w, h = _resolution_dims()
    ad_voice = cfg.get("DEFAULT_AD_VOICE") or "en-US-AriaNeural"

    reel_file = f"ad_reel_{prod_id}_{int(time.time())}.mp4"
    story_file = f"ad_story_{prod_id}_{int(time.time())}.mp4"

    reel_res = await render_vertical_video(
        output_filename=reel_file,
        script_text=ad_script,
        scene_paths=scene_paths,
        voice=ad_voice,
        cta_banner=cta_banner,
        width=w,
        height=h,
    )
    story_res = await render_vertical_video(
        output_filename=story_file,
        script_text=story_script,
        scene_paths=list(reversed(scene_paths)) if scene_paths else None,
        voice=ad_voice,
        cta_banner="TAP LINK • SHOP NOW",
        max_duration=12.0,
        width=w,
        height=h,
    )
    return web.json_response({"reel_ad": reel_res, "story_ad": story_res})


async def handle_approve_product(request: web.Request) -> web.Response:
    prod_id = request.match_info["product_id"]
    state = load_state()
    product = next((p for p in state["products"] if p["id"] == prod_id), None)
    if not product:
        return web.json_response({"error": "Product not found"}, status=404)
    product = await _execute_product_launch(product, state)
    return web.json_response({"status": "approved_and_published", "product": product})


def _build_daily_summary(state: Dict) -> Dict:
    cfg = load_raw_settings()
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    pending = [p for p in state["products"] if p["approval_status"] == "pending_approval"]
    published = [p for p in state["products"] if p["approval_status"] == "published_live"]
    ad_count = sum(len(p.get("ad_deployments", [])) for p in published)

    summary = {
        "date": today,
        "shorts_published_count": len(state["shorts_queue"]),
        "pending_approvals_count": len(pending),
        "published_products_count": len(published),
        "ad_placements_count": ad_count,
        "dashboard_url": cfg.get("PUBLIC_DASHBOARD_URL") or "http://localhost:8000",
    }
    wa_text = (
        f"🚀 *Viral AI Agent Daily Digest ({today})*\n\n"
        f"🎬 *AI Animated Shorts:* {summary['shorts_published_count']} rendered & queued on peak viral timeline (YT Shorts, TikTok, IG Reels)\n"
        f"🛍️ *Viral Products Awaiting Approval:* {summary['pending_approvals_count']} high-margin winners shortlisted today\n"
        f"🏪 *Live Multi-Store SKUs:* {summary['published_products_count']} synced on Shopify, Amazon & TikTok Shop\n"
        f"📢 *Product Ad Placements:* {summary['ad_placements_count']} scheduled across YT Shorts, IG Reels/Stories & TikTok Stories/Feed\n\n"
        f"👉 Review & 1-Click Approve: {summary['dashboard_url']}"
    )
    summary["whatsapp_digest_text"] = wa_text
    summary["email_digest_html"] = (
        f"<h3>Viral AI Commerce & Shorts Daily Digest ({today})</h3>"
        f"<p><strong>Animated Shorts Queued/Posted:</strong> {summary['shorts_published_count']}<br>"
        f"<strong>Products Awaiting Approval:</strong> {summary['pending_approvals_count']}<br>"
        f"<strong>Published Store SKUs:</strong> {summary['published_products_count']}<br>"
        f"<strong>Ad Video Placements:</strong> {summary['ad_placements_count']}</p>"
    )
    return summary


async def handle_daily_summary(request: web.Request) -> web.Response:
    state = load_state()
    return web.json_response(_build_daily_summary(state))


async def handle_send_daily_notification(request: web.Request) -> web.Response:
    state = load_state()
    summary = _build_daily_summary(state)
    dispatch = await send_daily_notifications(summary)
    state["notification_logs"].insert(
        0,
        {
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
            "type": "Daily WhatsApp + Email Digest Dispatched",
            "channels": ["WhatsApp Cloud API", "Email Digest"],
            "summary": f"Sent daily report ({summary['shorts_published_count']} Shorts, {summary['pending_approvals_count']} Pending Products, {summary['published_products_count']} Live SKUs).",
        },
    )
    save_state(state)
    return web.json_response({"summary": summary, "dispatch": dispatch})


async def handle_tiktok_shop_connector(request: web.Request) -> web.Response:
    body = await request.json()
    res = await publish_to_tiktok_shop(body)
    return web.json_response(res)


async def handle_log_short_published(request: web.Request) -> web.Response:
    body = await request.json()
    state = load_state()
    state["notification_logs"].insert(
        0,
        {
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
            "type": "Autopilot Short Published",
            "channels": body.get("platforms", ["youtube_shorts", "tiktok", "instagram_reels"]),
            "summary": f"Auto-published '{body.get('title', 'AI Short')}' with viral #tags on peak schedule.",
        },
    )
    save_state(state)
    return web.json_response({"status": "logged"})


async def handle_list_workflows(request: web.Request) -> web.Response:
    files = sorted(WORKFLOWS_DIR.glob("*.json"))
    items = []
    for f in files:
        data = json.loads(f.read_text(encoding="utf-8"))
        items.append(
            {
                "filename": f.name,
                "name": data.get("name", f.name),
                "node_count": len(data.get("nodes", [])),
                "size_kb": round(f.stat().st_size / 1024, 1),
            }
        )
    return web.json_response({"workflows": items})


async def handle_download_workflow(request: web.Request) -> web.Response:
    fname = Path(request.match_info["filename"]).name
    target = WORKFLOWS_DIR / fname
    if not target.exists():
        return web.json_response({"error": "Workflow file not found"}, status=404)
    return web.Response(
        body=target.read_bytes(),
        content_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="{fname}"'},
    )


async def handle_autopilot_run_short_now(request: web.Request) -> web.Response:
    """
    1-Tap Mobile Autopilot Trigger:
    Uses the user's configured LLM (OpenAI/Groq/OpenRouter) + CUSTOM_SHORTS_PROMPT from /setup
    (or smart fallback micro-story if LLM key isn't entered yet) to write, render, and queue a 9:16 Short!
    """
    cfg = load_raw_settings()
    style_id = cfg.get("SHORTS_NICHE_STYLE") or "pixar_micro_lore"
    style_obj = next((s for s in TRENDING_ANIMATION_STYLES if s["id"] == style_id), TRENDING_ANIMATION_STYLES[0])
    custom_prompt = cfg.get("CUSTOM_SHORTS_PROMPT") or "Write an emotional 3D Pixar-style micro-story in 42 words."

    title = "The Robot Who Bought Yesterday's Sunset"
    lil_desc = "He saved every spare coin for 90 years just to watch 10 seconds of real sunlight 🤖🌅"
    script_text = (
        "Underground citizens thought the sun was just an old fairy tale, until a rusty vending bot spent his life savings to open the roof hatch for ten golden seconds."
    )
    hashtags = style_obj["top_hashtags"]
    scene_prompts = None

    llm_key = cfg.get("LLM_API_KEY", "").strip()
    llm_base = (cfg.get("LLM_BASE_URL") or "https://api.openai.com/v1").rstrip("/")
    llm_model = cfg.get("LLM_MODEL") or "gpt-4o-mini"

    if llm_key:
        try:
            async with httpx.AsyncClient(timeout=25) as client:
                r = await client.post(
                    f"{llm_base}/chat/completions",
                    headers={"Authorization": f"Bearer {llm_key}", "Content-Type": "application/json"},
                    json={
                        "model": llm_model,
                        "response_format": {"type": "json_object"},
                        "messages": [
                            {
                                "role": "system",
                                "content": "Return JSON only with keys: title (max 54 chars), lil_viral_description (max 95 chars + emoji), voiceover_script (38-48 words), hashtags (array of 5 tags starting with #shorts), scene_prompts (array of 2 vertical 9:16 scene prompts with no text).",
                            },
                            {"role": "user", "content": custom_prompt},
                        ],
                    },
                )
                if r.status_code < 400:
                    parsed = json.loads(r.json()["choices"][0]["message"]["content"])
                    title = parsed.get("title") or title
                    lil_desc = parsed.get("lil_viral_description") or lil_desc
                    script_text = parsed.get("voiceover_script") or script_text
                    hashtags = parsed.get("hashtags") or hashtags
                    scene_prompts = parsed.get("scene_prompts")
        except Exception:
            pass

    w, h = _resolution_dims()
    filename = f"short_auto_{int(time.time())}.mp4"
    render_info = await render_vertical_video(
        output_filename=filename,
        script_text=script_text,
        scene_paths=None if scene_prompts else ["media/scenes/short_scene_1.jpg", "media/scenes/short_scene_2.jpg"],
        scene_prompts=scene_prompts,
        voice=cfg.get("DEFAULT_VOICE") or style_obj["voice"],
        width=w,
        height=h,
    )
    schedule = compute_best_publish_timeline(tz_offset_hours=_tz_offset())
    short_entry = {
        "id": f"short_{int(time.time())}",
        "title": title,
        "style_name": style_obj["name"],
        "lil_viral_description": lil_desc,
        "hashtags": hashtags,
        "script_text": script_text,
        "video_url": render_info["url"],
        "duration_sec": render_info["duration_sec"],
        "status": "scheduled_autopilot",
        "platforms": ["youtube_shorts", "tiktok", "instagram_reels"],
        "schedule": schedule,
        "created_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
    }
    state = load_state()
    state["shorts_queue"].insert(0, short_entry)
    state["notification_logs"].insert(
        0,
        {
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
            "type": "Mobile Cloud Autopilot Short Created",
            "channels": ["YouTube Shorts", "TikTok", "Instagram Reels"],
            "summary": f"Generated & queued '{title}' ({render_info['duration_sec']}s) for peak viral slot.",
        },
    )
    save_state(state)
    return web.json_response({**render_info, "short": short_entry})


async def _built_in_cloud_scheduler(app: web.Application) -> None:
    """
    Lightweight built-in scheduler for Android / Single-Container Cloud deployments!
    When BUILT_IN_SCHEDULER == 'enabled' (default), dispatches the 20:00 daily digest
    automatically even if the user deployed without a separate n8n container.
    """
    last_digest_day = ""
    while True:
        try:
            await asyncio.sleep(60)
            cfg = load_raw_settings()
            if cfg.get("BUILT_IN_SCHEDULER", "enabled") != "enabled":
                continue
            now_utc = datetime.now(timezone.utc)
            local_hour = (now_utc.hour + _tz_offset()) % 24
            day_key = now_utc.strftime("%Y-%m-%d")
            if local_hour == 20 and last_digest_day != day_key:
                last_digest_day = day_key
                state = load_state()
                await send_daily_notifications(_build_daily_summary(state))
        except asyncio.CancelledError:
            break
        except Exception:
            pass


async def _start_bg_tasks(app: web.Application) -> None:
    app["scheduler_task"] = asyncio.create_task(_built_in_cloud_scheduler(app))


async def _stop_bg_tasks(app: web.Application) -> None:
    task = app.get("scheduler_task")
    if task:
        task.cancel()


def create_app() -> web.Application:
    app = web.Application(middlewares=[cors_and_security_middleware])
    load_raw_settings()
    load_state()
    app.on_startup.append(_start_bg_tasks)
    app.on_cleanup.append(_stop_bg_tasks)

    # Pages
    app.router.add_get("/", handle_index)
    app.router.add_get("/setup", handle_setup_page)
    app.router.add_post("/api/autopilot/run-short-now", handle_autopilot_run_short_now)

    # Genuine Setup, Live Connection Tests & OAuth2
    app.router.add_get("/api/setup/config", handle_get_setup_config)
    app.router.add_post("/api/setup/config", handle_save_setup_config)
    app.router.add_post("/api/setup/test/{provider}", handle_test_provider)
    app.router.add_post("/api/setup/deploy-n8n", handle_deploy_n8n)
    app.router.add_get("/api/setup/export-env", handle_export_env)
    app.router.add_get("/api/setup/download-zip", handle_download_project_zip)
    app.router.add_get("/api/config/runtime", handle_runtime_config_for_n8n)
    app.router.add_get("/api/oauth/{provider}/start", handle_oauth_start)
    app.router.add_get("/api/oauth/{provider}/callback", handle_oauth_callback)

    # Core Agent & n8n Worker API
    app.router.add_get("/api/state", handle_get_state)
    app.router.add_get("/api/trends/styles", handle_trend_styles)
    app.router.add_get("/api/trends/tiktok-products", handle_tiktok_products)
    app.router.add_post("/api/render/short", handle_render_short)
    app.router.add_post("/api/render/product-ad", handle_render_product_ad)
    app.router.add_post("/api/products/shortlist", handle_shortlist_product)
    app.router.add_post("/api/products/{product_id}/approve", handle_approve_product)
    app.router.add_get("/api/summary/daily", handle_daily_summary)
    app.router.add_post("/api/notifications/send-daily", handle_send_daily_notification)
    app.router.add_post("/api/connectors/tiktok-shop/publish", handle_tiktok_shop_connector)
    app.router.add_post("/api/logs/short-published", handle_log_short_published)
    app.router.add_get("/api/workflows", handle_list_workflows)
    app.router.add_get("/api/workflows/{filename}", handle_download_workflow)

    app.router.add_static("/media", MEDIA_DIR, show_index=False)
    app.router.add_static("/static", STATIC_DIR, show_index=False)
    return app


if __name__ == "__main__":
    port = int(os.getenv("PORT", "8000"))
    web.run_app(create_app(), host="0.0.0.0", port=port)
