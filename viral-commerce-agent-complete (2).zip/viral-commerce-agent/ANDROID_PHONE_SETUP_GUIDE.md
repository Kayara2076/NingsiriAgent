# 📱 Complete Android Phone Setup Guide (100% Phone — Zero Laptop Needed!)

You do **NOT** need a computer, laptop, or coding terminal to run this system!  
We have upgraded **PulseAgent** with **Single-Container Cloud Mode**, **1-Tap Mobile Prompt Buttons**, and **Android Home-Screen App Installation (PWA)** so your Android phone acts as your remote control while a free cloud server renders the FFmpeg videos and runs 24/7 without draining your battery.

---

## 💡 Why Cloud + Android Remote Control Beats Running Inside Your Phone
If an AI video generator ran directly on your phone's processor, Android's battery saver would kill it every time you locked your screen, and Instagram/TikTok couldn't reach your `.mp4` videos.  
Instead:
1. **A Free Cloud Server (Hugging Face Spaces / Render / Railway)** does all the heavy FFmpeg rendering and gives you a **free automatic `https://` public link** *(so you skip Cloudflare Tunnel completely!)*.
2. **Your Android Phone** gets a **PulseAgent App Icon** on your Home Screen where you paste keys, watch previews, and tap **Approve & Publish** with your thumb.

---

## 📲 STEP 1: Download & Unzip on Your Android Phone (2 Minutes)

1. In the **Agent Command & Setup Hub** preview right here, tap **⚙️ Live Setup & API Connections** → tap **📦 Download Full Project (.zip)**.
2. Open the **Files by Google** app on your Android phone *(or free **ZArchiver** from Play Store)* → go to **Downloads**.
3. Tap **`viral-commerce-agent-complete.zip`** → tap **Extract** → Done! You now have the `viral-commerce-agent` folder on your phone.

---

## ☁️ STEP 2: Put Your Agent Online for $0 Using Android Chrome (5 Minutes)

### Easiest $0 Method: Free Hugging Face Docker Space (2 CPU + 16 GB RAM Free!)
1. Open **Chrome** on your Android phone and go to **[huggingface.co/join](https://huggingface.co/join)** → create a free account and verify your email.
2. Tap your **Profile Icon (top right)** → tap **+ New Space**:
   - **Space name:** `my-viral-agent`
   - **Select the Space SDK:** Tap **Docker** → select **Blank**
   - **Visibility:** Public *(needed so Instagram & TikTok APIs can download your rendered `.mp4` videos)*
   - Tap **Create Space**.
3. Near the top of your new Space, tap the **`Files`** tab → tap **`+ Add file` → `Upload files`**.
4. Tap **Choose files**, open your extracted `viral-commerce-agent` folder in **Downloads**, select the main files (`Dockerfile`, `README.md`, `requirements.txt`, `server.py`, `.env.example`), and tap **Commit changes to `main`**.
   - *(Note: If Android's file picker doesn't upload sub-folders at once, tap **`+ Add file` → `Create a new file`**, or—even faster—install the free **GitHub** Android app or open `github.com/new` in Chrome with **Desktop site** checked, upload the folder once, and connect that GitHub repo on **[render.com](https://render.com/)** → **New Web Service**! Both ways are 100% free and take 3 minutes).*
5. Wait **~2 minutes** while the badge at the top changes from `Building` (blue) to **`Running` (green)**!
6. Tap the **`⋮` (three dots)** inside your Hugging Face Space → tap **Embed this Space** → copy the **Direct URL** (it looks like `https://yourname-my-viral-agent.hf.space`) and open that link in a new Chrome tab!

---

## 🏠 STEP 3: Install PulseAgent to Your Android Home Screen (30 Seconds)

1. With your new `https://...hf.space` link open in **Android Chrome**, tap Chrome's top-right **`⋮` (three vertical dots)**.
2. Tap **Add to Home screen** → tap **Install** (or **Add**).
3. Go to your Android phone's Home Screen—you now have the **⚡ PulseAgent** app icon right next to WhatsApp, TikTok, and YouTube!

---

## 🧠 STEP 4: Set Up Your Free AI Brain & Niche Prompt by Thumb (3 Minutes)

Open your **⚡ PulseAgent** app → tap **⚙️ Live Setup & API Connections**:

### 4A. Pick Your Shorts Style with 1 Tap (No Code or JSON!)
1. On **Step 1 (`1. Engine & Rules`)** in the horizontal top bar:
   - Keep **Built-In Cloud Autopilot Scheduler** set to **`Enabled (Best for Phone Setup!)`** *(this runs your daily schedule right inside the app without needing a second computer!)*.
   - Under **✍️ 1-Tap Viral Shorts Niche Prompt**, tap your favorite button:
     - **🎨 3D Pixar Story**
     - **🧠 Psychology Anime**
     - **🌍 Weird History**
     *(Or type your own idea in plain English right into that box!)*
   - Make sure **Public HTTPS Media URL** shows your `https://...hf.space` link.

### 4B. Plug In Your Free Groq AI Key ($0.00)
1. In Chrome on Android, open **[console.groq.com/keys](https://console.groq.com/keys)** → Sign in with Google → tap **Create API Key** → tap **Copy** (`gsk_...`).
2. Switch back to **PulseAgent → `/setup` → swipe the step bar to `2. AI Brain & n8n`**:
   - Tap **`Preset: Groq Free/Fast (Llama 3.3 70B)`**
   - Long-press inside **LLM API Key** → **Paste** your `gsk_...` key.
   - Tap **🧪 Test Live LLM Completion** → Watch it turn **`✓ Verified Live`**!
   - Tap **💾 Save All Settings** at the top!

> **Optional n8n Visual Canvas on Phone:** Because `Built-In Cloud Autopilot Scheduler` is enabled, your app already runs without needing a separate server! If you *also* want the visual n8n workflow canvas on your phone later, create a free trial at `n8n.cloud` (or a $5 Railway n8n template), paste its API key into Step 2, and tap **🚀 Auto-Push All 4 Workflows to n8n**.

---

## 📱 STEP 5: Pro Android Trick for Connecting Social & Store Keys (10 Minutes)

> **🔥 GOLDEN ANDROID CHROME TRICK:**  
> Developer portals (Google Cloud, Facebook Developers, Shopify Admin) sometimes hide buttons on small mobile screens. Whenever you open those websites in Android Chrome, tap Chrome's top-right **`⋮` → check the box `Desktop site` ☑**! Then pinch-to-zoom comfortably.

Connect these in this exact beginner-friendly order on `/setup`:

### 1️⃣ Shopify Store First (`4. Shopify, Amazon & TT` tab — Takes 60 Seconds!)
1. Open `your-store.myshopify.com/admin` in Chrome → **Settings → Apps and sales channels → Develop apps → Create an app (`PulseAgent`)**.
2. Tap **Configure Admin API scopes** → tick `write_products`, `read_products`, `read_orders`, `write_inventory` → **Save → Install app → Reveal token once** → Copy `shpat_...`.
3. Paste your store domain and `shpat_...` into **PulseAgent `/setup` → Step 4** → tap **🧪 Verify Shopify Store**.
*(Save Amazon SP-API & TikTok Shop for Week 2 once your seller verification IDs are approved!)*

### 2️⃣ Daily Email + WhatsApp Alerts (`5. WhatsApp & Email` tab — Takes 2 Minutes!)
1. Open **[resend.com](https://resend.com/)** in Chrome → Sign up free → **API Keys → Create API Key** → Copy `re_...`.
2. In **PulseAgent `/setup` → Step 5**, type your email address, paste `re_...` into **Resend API Key**, and tap **✉️ Send Real Test Email** → Your Android Gmail notification will chime immediately!
3. For WhatsApp: In **[developers.facebook.com/apps](https://developers.facebook.com/apps)** *(with `Desktop site` checked)* → Create Business App → Add **WhatsApp** → copy **Phone Number ID** + **Token** into Step 5 → tap **📲 Send Real Test WhatsApp**.

### 3️⃣ YouTube Shorts, Instagram Reels/Stories & TikTok (`3. YT, IG & TikTok` tab)
1. **YouTube:** Open **[console.cloud.google.com](https://console.cloud.google.com/)** *(with `Desktop site` checked)* → Enable **YouTube Data API v3** → Create **OAuth Client ID (Web application)** → tap **Copy URI** in PulseAgent Step 3 and paste it into Google's *Authorized redirect URIs* → paste **Client ID** & **Client Secret** into Step 3 → tap **🔗 Connect YouTube via Google OAuth2** and tap Allow on your Google account!
2. **Instagram:** Make sure your IG app is set to **Creator/Business** + linked to a Facebook Page → generate token in Meta Graph Explorer (`instagram_basic`, `instagram_content_publish`) → paste into Step 3 → tap **🔄 Exchange 60-Day Token & Verify**.
3. **TikTok:** At **[developers.tiktok.com](https://developers.tiktok.com/)** *(with `Desktop site` checked)* → enable **Content Posting API**, paste the Redirect URI from Step 3, enter Client Key & Secret, and tap **🔗 Connect TikTok OAuth2**.

---

## ⚡ STEP 6: How You Run Everything Daily From Your Android Phone (3 Mins/Day)

1. **Test Your First AI Short Right Now:** Open your **⚡ PulseAgent** app → tap **Tab 2 (`AI Animated Shorts Studio`)** → tap the purple button **🤖 1-Tap AI Autopilot (Write + Render)**. In ~16 seconds, watch your newly written, voiced, and captioned vertical video right on your phone!
2. **Morning Routine (2 Mins):** Tap the link in your morning WhatsApp/Email alert → swipe through the **3 Viral Product Shortlist cards** on **Tab 3** → tap **▶ Watch Rendered Reel Ad & 15s Story Cut** → tap **🚀 Approve & Publish** on your favorite high-margin winner!
3. **Evening Routine (30 Secs):** Check your 8:00 PM WhatsApp summary to see how many Shorts, Product Ads, and Store Listings went live today.
