#!/usr/bin/env bash
set -e

echo "=========================================================="
echo " 🚀 PulseAgent — 1-Click Beginner Launcher (Mac/Linux/VPS)"
echo "=========================================================="

if ! command -v docker >/dev/null 2>&1; then
  echo "❌ Docker is not installed yet!"
  echo "👉 Download Docker Desktop free at: https://www.docker.com/products/docker-desktop/"
  exit 1
fi

if [ ! -f .env ]; then
  cp .env.example .env
  echo "✅ Created initial .env configuration file."
fi

echo "⏳ Starting n8n Orchestrator + FFmpeg Video Worker + Setup Hub..."
docker compose up -d --build

echo ""
echo "🎉 SUCCESS! Your AI Agent System is LIVE:"
echo "   1️⃣ Open Setup Wizard first:    http://localhost:8000/setup"
echo "   2️⃣ Open Command Dashboard:     http://localhost:8000"
echo "   3️⃣ Open n8n Workflow Canvas:   http://localhost:5678"
echo "=========================================================="
