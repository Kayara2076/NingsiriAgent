#!/usr/bin/env python3
"""
Genuine Live API Connection Testers, OAuth2 Helpers & n8n Auto-Deployer
-----------------------------------------------------------------------
Called by `/api/setup/test/{provider}`, `/api/setup/deploy-n8n`, and `/api/oauth/...`
so every integration card on `/setup` performs real live verification against actual APIs.
"""

import hashlib
import hmac
import json
import shutil
import smtplib
import subprocess
import time
import urllib.parse
from email.mime.text import MIMEText
from pathlib import Path
from typing import Dict, Tuple

import httpx

from worker.config_manager import (
    load_raw_settings,
    record_connection_status,
    save_raw_settings,
)

BASE_DIR = Path(__file__).resolve().parent.parent
WORKFLOWS_DIR = BASE_DIR / "n8n-workflows"


def _clean_shopify_domain(domain: str) -> str:
    d = domain.strip().replace("https://", "").replace("http://", "").split("/")[0]
    return d


async def test_ffmpeg_tts() -> Dict:
    """Verify local FFmpeg binary, libass subtitle renderer, edge-tts module, and media storage."""
    t0 = time.perf_counter()
    ff = shutil.which("ffmpeg")
    if not ff:
        return record_connection_status("ffmpeg_tts", False, "FFmpeg binary not found in PATH.")

    ver_proc = subprocess.run(["ffmpeg", "-version"], capture_output=True, text=True)
    first_line = (ver_proc.stdout.splitlines() or ["ffmpeg"])[0]
    filters_proc = subprocess.run(["ffmpeg", "-filters"], capture_output=True, text=True)
    has_ass = " ass " in filters_proc.stdout or "subtitles" in filters_proc.stdout

    has_edge_tts = False
    try:
        import edge_tts  # noqa: F401
        has_edge_tts = True
    except ImportError:
        pass

    disk = shutil.disk_usage(BASE_DIR)
    free_gb = round(disk.free / (1024 ** 3), 2)
    ms = int((time.perf_counter() - t0) * 1000)

    ok = bool(ff and has_ass)
    msg = (
        f"Ready ({ms}ms) • {first_line.split('Copyright')[0].strip()} • "
        f"libass={'OK' if has_ass else 'MISSING'} • edge-tts={'OK' if has_edge_tts else 'Fallback'} • {free_gb} GB free"
    )
    return record_connection_status(
        "ffmpeg_tts",
        ok,
        msg,
        {"ffmpeg": first_line, "libass": has_ass, "edge_tts": has_edge_tts, "free_gb": free_gb},
    )


async def test_llm() -> Dict:
    """Verify LLM endpoint & API key with a real live model/completion check."""
    cfg = load_raw_settings()
    api_key = cfg.get("LLM_API_KEY", "").strip()
    base_url = (cfg.get("LLM_BASE_URL") or "https://api.openai.com/v1").rstrip("/")
    model = cfg.get("LLM_MODEL") or "gpt-4o-mini"

    if not api_key and "localhost" not in base_url and "127.0.0.1" not in base_url:
        return record_connection_status("llm", False, "Missing LLM_API_KEY. Paste your OpenAI, Groq, or OpenRouter key.")

    t0 = time.perf_counter()
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    try:
        async with httpx.AsyncClient(timeout=18) as client:
            resp = await client.post(
                f"{base_url}/chat/completions",
                headers=headers,
                json={
                    "model": model,
                    "max_tokens": 8,
                    "messages": [{"role": "user", "content": "Reply with OK"}],
                },
            )
            ms = int((time.perf_counter() - t0) * 1000)
            if resp.status_code >= 400:
                return record_connection_status(
                    "llm", False, f"HTTP {resp.status_code} from {base_url}: {resp.text[:180]}"
                )
            data = resp.json()
            used_model = data.get("model", model)
            return record_connection_status(
                "llm",
                True,
                f"Verified live LLM ({used_model}) in {ms}ms via {base_url}",
                {"model": used_model, "latency_ms": ms},
            )
    except Exception as exc:
        return record_connection_status("llm", False, f"Connection error: {exc}")


async def test_shopify() -> Dict:
    """Verify Shopify Store Domain & Admin API Access Token via GET /admin/api/2025-01/shop.json."""
    cfg = load_raw_settings()
    domain = _clean_shopify_domain(cfg.get("SHOPIFY_STORE_DOMAIN", ""))
    token = cfg.get("SHOPIFY_ADMIN_ACCESS_TOKEN", "").strip()
    if not domain or not token:
        return record_connection_status(
            "shopify", False, "Enter both SHOPIFY_STORE_DOMAIN (e.g. brand.myshopify.com) and SHOPIFY_ADMIN_ACCESS_TOKEN."
        )

    if domain != cfg.get("SHOPIFY_STORE_DOMAIN"):
        cfg["SHOPIFY_STORE_DOMAIN"] = domain
        save_raw_settings(cfg)

    t0 = time.perf_counter()
    try:
        async with httpx.AsyncClient(timeout=18) as client:
            resp = await client.get(
                f"https://{domain}/admin/api/2025-01/shop.json",
                headers={"X-Shopify-Access-Token": token},
            )
            ms = int((time.perf_counter() - t0) * 1000)
            if resp.status_code >= 400:
                return record_connection_status(
                    "shopify", False, f"Shopify HTTP {resp.status_code}: {resp.text[:180]}"
                )
            shop = resp.json().get("shop", {})
            msg = f"Connected to '{shop.get('name')}' ({shop.get('domain')} • {shop.get('currency')} • {shop.get('plan_display_name')}) in {ms}ms"
            return record_connection_status("shopify", True, msg, {"shop_name": shop.get("name"), "currency": shop.get("currency")})
    except Exception as exc:
        return record_connection_status("shopify", False, f"Shopify request failed: {exc}")


async def test_amazon() -> Dict:
    """Exchange Amazon LWA Refresh Token for Access Token and verify Seller Marketplace Participation."""
    cfg = load_raw_settings()
    cid = cfg.get("AMAZON_LWA_CLIENT_ID", "").strip()
    csec = cfg.get("AMAZON_LWA_CLIENT_SECRET", "").strip()
    rtok = cfg.get("AMAZON_SP_REFRESH_TOKEN", "").strip()
    seller_id = cfg.get("AMAZON_SELLER_ID", "").strip()

    if not (cid and csec and rtok):
        return record_connection_status(
            "amazon", False, "Enter AMAZON_LWA_CLIENT_ID, AMAZON_LWA_CLIENT_SECRET, and AMAZON_SP_REFRESH_TOKEN."
        )

    t0 = time.perf_counter()
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            tok_resp = await client.post(
                "https://api.amazon.com/auth/o2/token",
                data={
                    "grant_type": "refresh_token",
                    "refresh_token": rtok,
                    "client_id": cid,
                    "client_secret": csec,
                },
            )
            if tok_resp.status_code >= 400:
                return record_connection_status(
                    "amazon", False, f"LWA Token Exchange HTTP {tok_resp.status_code}: {tok_resp.text[:180]}"
                )
            access_token = tok_resp.json()["access_token"]
            cfg["AMAZON_LWA_ACCESS_TOKEN"] = access_token
            save_raw_settings(cfg)

            part_resp = await client.get(
                "https://sellingpartnerapi-na.amazon.com/sellers/v1/marketplaceParticipations",
                headers={"x-amz-access-token": access_token},
            )
            ms = int((time.perf_counter() - t0) * 1000)
            if part_resp.status_code < 400:
                payload = part_resp.json().get("payload", [])
                markets = [p.get("marketplace", {}).get("countryCode", "") for p in payload]
                return record_connection_status(
                    "amazon",
                    True,
                    f"LWA Token Refreshed & SP-API Verified ({', '.join(markets) or 'Active'}) • Seller {seller_id or 'OK'} ({ms}ms)",
                )
            return record_connection_status(
                "amazon",
                True,
                f"Amazon LWA Refresh Token verified & access token saved ({ms}ms). Note: Sellers endpoint returned HTTP {part_resp.status_code}.",
            )
    except Exception as exc:
        return record_connection_status("amazon", False, f"Amazon SP-API test error: {exc}")


async def test_tiktok_shop() -> Dict:
    """Sign HMAC-SHA256 request to TikTok Shop Partner API & auto-discover shop_cipher if blank."""
    cfg = load_raw_settings()
    app_key = cfg.get("TIKTOK_SHOP_APP_KEY", "").strip()
    app_secret = cfg.get("TIKTOK_SHOP_APP_SECRET", "").strip()
    access_token = cfg.get("TIKTOK_SHOP_ACCESS_TOKEN", "").strip()

    if not (app_key and app_secret and access_token):
        return record_connection_status(
            "tiktok_shop", False, "Enter TIKTOK_SHOP_APP_KEY, TIKTOK_SHOP_APP_SECRET, and TIKTOK_SHOP_ACCESS_TOKEN."
        )

    path = "/authorization/202309/shops"
    params = {"app_key": app_key, "timestamp": str(int(time.time()))}
    sorted_params = "".join(f"{k}{params[k]}" for k in sorted(params.keys()))
    base_str = f"{app_secret}{path}{sorted_params}{app_secret}"
    params["sign"] = hmac.new(app_secret.encode("utf-8"), base_str.encode("utf-8"), hashlib.sha256).hexdigest()

    t0 = time.perf_counter()
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.get(
                f"https://open-api.tiktokglobalshop.com{path}",
                params=params,
                headers={"x-tts-access-token": access_token},
            )
            ms = int((time.perf_counter() - t0) * 1000)
            data = resp.json()
            if resp.status_code >= 400 or data.get("code", 0) != 0:
                return record_connection_status(
                    "tiktok_shop", False, f"TikTok Shop API response: {json.dumps(data)[:190]}"
                )
            shops = data.get("data", {}).get("shops", [])
            if shops and not cfg.get("TIKTOK_SHOP_CIPHER"):
                cfg["TIKTOK_SHOP_CIPHER"] = shops[0].get("cipher", "")
                save_raw_settings(cfg)
            shop_names = ", ".join(s.get("name", "Shop") for s in shops) or "Authorized"
            return record_connection_status(
                "tiktok_shop", True, f"Verified TikTok Shop ({shop_names}) & synced Shop Cipher in {ms}ms"
            )
    except Exception as exc:
        return record_connection_status("tiktok_shop", False, f"TikTok Shop error: {exc}")


async def test_youtube() -> Dict:
    """Auto-refresh Google OAuth token if refresh_token is stored, then verify YouTube Channel & Data API."""
    cfg = load_raw_settings()
    cid = cfg.get("GOOGLE_CLIENT_ID", "").strip()
    csec = cfg.get("GOOGLE_CLIENT_SECRET", "").strip()
    rtok = cfg.get("YOUTUBE_REFRESH_TOKEN", "").strip()
    atok = cfg.get("YOUTUBE_OAUTH_ACCESS_TOKEN", "").strip()
    api_key = cfg.get("YOUTUBE_API_KEY", "").strip()

    t0 = time.perf_counter()
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            if cid and csec and rtok:
                tr = await client.post(
                    "https://oauth2.googleapis.com/token",
                    data={
                        "client_id": cid,
                        "client_secret": csec,
                        "refresh_token": rtok,
                        "grant_type": "refresh_token",
                    },
                )
                if tr.status_code < 400:
                    atok = tr.json()["access_token"]
                    cfg["YOUTUBE_OAUTH_ACCESS_TOKEN"] = atok
                    save_raw_settings(cfg)
                else:
                    return record_connection_status(
                        "youtube", False, f"Google OAuth refresh failed ({tr.status_code}): {tr.text[:170]}"
                    )

            if atok:
                ch_resp = await client.get(
                    "https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&mine=true",
                    headers={"Authorization": f"Bearer {atok}"},
                )
                ms = int((time.perf_counter() - t0) * 1000)
                if ch_resp.status_code >= 400:
                    return record_connection_status(
                        "youtube", False, f"YouTube OAuth HTTP {ch_resp.status_code}: {ch_resp.text[:170]}"
                    )
                items = ch_resp.json().get("items", [])
                if items:
                    title = items[0]["snippet"]["title"]
                    subs = items[0]["statistics"].get("subscriberCount", "0")
                    return record_connection_status(
                        "youtube", True, f"Connected to YouTube Channel '{title}' ({subs} subscribers) • Upload Ready ({ms}ms)"
                    )
                return record_connection_status("youtube", True, f"YouTube OAuth token valid ({ms}ms), no channel initialized yet.")

            if api_key:
                kr = await client.get(
                    "https://www.googleapis.com/youtube/v3/videos",
                    params={"part": "id", "chart": "mostPopular", "maxResults": 1, "key": api_key},
                )
                ms = int((time.perf_counter() - t0) * 1000)
                if kr.status_code < 400:
                    return record_connection_status(
                        "youtube",
                        True,
                        f"YouTube Trend API Key verified ({ms}ms). Connect OAuth2 token as well to enable auto-uploading Shorts.",
                    )
                return record_connection_status("youtube", False, f"YouTube API Key HTTP {kr.status_code}: {kr.text[:160]}")

            return record_connection_status(
                "youtube", False, "Connect Google OAuth2 (for Shorts upload) or paste YOUTUBE_API_KEY / YOUTUBE_OAUTH_ACCESS_TOKEN."
            )
    except Exception as exc:
        return record_connection_status("youtube", False, f"YouTube connection error: {exc}")


async def test_instagram(exchange_long_lived: bool = False) -> Dict:
    """Verify Instagram Business Account ID & Meta Graph Token (optional 60-day token exchange)."""
    cfg = load_raw_settings()
    ig_id = cfg.get("IG_BUSINESS_USER_ID", "").strip()
    token = cfg.get("META_GRAPH_ACCESS_TOKEN", "").strip()
    app_id = cfg.get("META_APP_ID", "").strip()
    app_secret = cfg.get("META_APP_SECRET", "").strip()

    if not (ig_id and token):
        return record_connection_status(
            "instagram", False, "Enter IG_BUSINESS_USER_ID and META_GRAPH_ACCESS_TOKEN."
        )

    t0 = time.perf_counter()
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            if exchange_long_lived and app_id and app_secret:
                ex = await client.get(
                    "https://graph.facebook.com/v21.0/oauth/access_token",
                    params={
                        "grant_type": "fb_exchange_token",
                        "client_id": app_id,
                        "client_secret": app_secret,
                        "fb_exchange_token": token,
                    },
                )
                if ex.status_code < 400 and ex.json().get("access_token"):
                    token = ex.json()["access_token"]
                    cfg["META_GRAPH_ACCESS_TOKEN"] = token
                    save_raw_settings(cfg)

            resp = await client.get(
                f"https://graph.facebook.com/v21.0/{ig_id}",
                params={"fields": "id,username,followers_count,media_count", "access_token": token},
            )
            ms = int((time.perf_counter() - t0) * 1000)
            if resp.status_code >= 400:
                return record_connection_status(
                    "instagram", False, f"Meta Graph HTTP {resp.status_code}: {resp.text[:180]}"
                )
            d = resp.json()
            return record_connection_status(
                "instagram",
                True,
                f"Connected to @{d.get('username', ig_id)} ({d.get('followers_count', 0)} followers) • Reels & Stories Ready ({ms}ms)",
            )
    except Exception as exc:
        return record_connection_status("instagram", False, f"Instagram Graph error: {exc}")


async def test_tiktok() -> Dict:
    """Auto-refresh TikTok token if configured and verify Content Posting API v2 identity."""
    cfg = load_raw_settings()
    ckey = cfg.get("TIKTOK_CLIENT_KEY", "").strip()
    csec = cfg.get("TIKTOK_CLIENT_SECRET", "").strip()
    rtok = cfg.get("TIKTOK_REFRESH_TOKEN", "").strip()
    atok = cfg.get("TIKTOK_ACCESS_TOKEN", "").strip()

    t0 = time.perf_counter()
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            if ckey and csec and rtok:
                tr = await client.post(
                    "https://open.tiktokapis.com/v2/oauth/token/",
                    headers={"Content-Type": "application/x-www-form-urlencoded"},
                    data={
                        "client_key": ckey,
                        "client_secret": csec,
                        "grant_type": "refresh_token",
                        "refresh_token": rtok,
                    },
                )
                if tr.status_code < 400 and tr.json().get("access_token"):
                    atok = tr.json()["access_token"]
                    cfg["TIKTOK_ACCESS_TOKEN"] = atok
                    if tr.json().get("refresh_token"):
                        cfg["TIKTOK_REFRESH_TOKEN"] = tr.json()["refresh_token"]
                    save_raw_settings(cfg)

            if not atok:
                return record_connection_status("tiktok", False, "Connect TikTok OAuth2 or paste TIKTOK_ACCESS_TOKEN.")

            resp = await client.post(
                "https://open.tiktokapis.com/v2/post/publish/creator_info/query/",
                headers={"Authorization": f"Bearer {atok}", "Content-Type": "application/json; charset=UTF-8"},
            )
            ms = int((time.perf_counter() - t0) * 1000)
            if resp.status_code >= 400:
                return record_connection_status(
                    "tiktok", False, f"TikTok API HTTP {resp.status_code}: {resp.text[:180]}"
                )
            info = resp.json().get("data", {})
            nick = info.get("creator_nickname") or info.get("creator_username") or "Creator Account"
            return record_connection_status(
                "tiktok", True, f"Connected to TikTok '{nick}' • Video & Story Inbox Publishing Ready ({ms}ms)"
            )
    except Exception as exc:
        return record_connection_status("tiktok", False, f"TikTok API error: {exc}")


async def test_whatsapp(send_ping: bool = False) -> Dict:
    """Verify WhatsApp Cloud API Phone ID & optionally send a real test message to WHATSAPP_RECIPIENT_TO."""
    cfg = load_raw_settings()
    phone_id = cfg.get("WHATSAPP_PHONE_NUMBER_ID", "").strip()
    token = cfg.get("WHATSAPP_ACCESS_TOKEN", "").strip()
    recipient = cfg.get("WHATSAPP_RECIPIENT_TO", "").strip()

    if not (phone_id and token):
        return record_connection_status(
            "whatsapp", False, "Enter WHATSAPP_PHONE_NUMBER_ID and WHATSAPP_ACCESS_TOKEN from Meta App Dashboard."
        )

    t0 = time.perf_counter()
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.get(
                f"https://graph.facebook.com/v21.0/{phone_id}",
                params={"fields": "display_phone_number,verified_name,quality_rating"},
                headers={"Authorization": f"Bearer {token}"},
            )
            if resp.status_code >= 400:
                return record_connection_status(
                    "whatsapp", False, f"WhatsApp Cloud HTTP {resp.status_code}: {resp.text[:180]}"
                )
            d = resp.json()
            ping_note = ""
            if send_ping and recipient:
                pr = await client.post(
                    f"https://graph.facebook.com/v21.0/{phone_id}/messages",
                    headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                    json={
                        "messaging_product": "whatsapp",
                        "to": recipient,
                        "type": "text",
                        "text": {"body": "✅ PulseAgent Setup Verified! Daily Viral Shorts & Store Shortlists are now linked to your WhatsApp."},
                    },
                )
                ping_note = f" • Test message sent to {recipient} (HTTP {pr.status_code})"
            ms = int((time.perf_counter() - t0) * 1000)
            return record_connection_status(
                "whatsapp",
                True,
                f"Verified '{d.get('verified_name', 'Business')}' ({d.get('display_phone_number', phone_id)}) in {ms}ms{ping_note}",
            )
    except Exception as exc:
        return record_connection_status("whatsapp", False, f"WhatsApp error: {exc}")


async def test_email(send_ping: bool = False) -> Dict:
    """Verify Resend API or real SMTP TLS login, and optionally send a live test email."""
    cfg = load_raw_settings()
    to_addr = cfg.get("NOTIFY_EMAIL_TO", "").strip()
    from_addr = cfg.get("EMAIL_FROM", "agent@yourdomain.com").strip()
    resend_key = cfg.get("RESEND_API_KEY", "").strip()
    smtp_host = cfg.get("SMTP_HOST", "").strip()
    smtp_port = int(cfg.get("SMTP_PORT") or "587")
    smtp_user = cfg.get("SMTP_USER", "").strip()
    smtp_pass = cfg.get("SMTP_PASS", "").strip()

    t0 = time.perf_counter()
    try:
        if resend_key:
            async with httpx.AsyncClient(timeout=18) as client:
                if send_ping and to_addr:
                    r = await client.post(
                        "https://api.resend.com/emails",
                        headers={"Authorization": f"Bearer {resend_key}", "Content-Type": "application/json"},
                        json={
                            "from": from_addr,
                            "to": [to_addr],
                            "subject": "✅ PulseAgent Email Notifications Connected!",
                            "html": "<p>Your <strong>PulseAgent Daily Digest & Product Approval Alerts</strong> are live.</p>",
                        },
                    )
                    ms = int((time.perf_counter() - t0) * 1000)
                    if r.status_code >= 400:
                        return record_connection_status("email", False, f"Resend HTTP {r.status_code}: {r.text[:170]}")
                    return record_connection_status("email", True, f"Sent live test email via Resend to {to_addr} ({ms}ms)")
                r = await client.get(
                    "https://api.resend.com/domains",
                    headers={"Authorization": f"Bearer {resend_key}"},
                )
                ms = int((time.perf_counter() - t0) * 1000)
                if r.status_code >= 400:
                    return record_connection_status("email", False, f"Resend HTTP {r.status_code}: {r.text[:170]}")
                return record_connection_status("email", True, f"Resend API key verified ({ms}ms)")

        if smtp_host and smtp_user and smtp_pass:
            with smtplib.SMTP(smtp_host, smtp_port, timeout=15) as server:
                server.ehlo()
                server.starttls()
                server.login(smtp_user, smtp_pass)
                if send_ping and to_addr:
                    msg = MIMEText("PulseAgent SMTP setup verified! Daily viral shorts & store digests are active.")
                    msg["Subject"] = "✅ PulseAgent SMTP Connected"
                    msg["From"] = from_addr or smtp_user
                    msg["To"] = to_addr
                    server.sendmail(msg["From"], [to_addr], msg.as_string())
            ms = int((time.perf_counter() - t0) * 1000)
            extra = f" & sent test email to {to_addr}" if (send_ping and to_addr) else ""
            return record_connection_status("email", True, f"SMTP TLS login verified on {smtp_host}:{smtp_port} ({ms}ms){extra}")

        return record_connection_status("email", False, "Enter either RESEND_API_KEY or SMTP_HOST + SMTP_USER + SMTP_PASS.")
    except Exception as exc:
        return record_connection_status("email", False, f"Email connection failed: {exc}")


async def test_or_deploy_n8n(deploy_workflows: bool = False) -> Dict:
    """
    Connect to a live n8n instance via `X-N8N-API-KEY`.
    When `deploy_workflows=True`, pushes all 4 `.json` workflows straight into n8n via `/api/v1/workflows`!
    """
    cfg = load_raw_settings()
    base_url = (cfg.get("N8N_BASE_URL") or "http://localhost:5678").rstrip("/")
    api_key = cfg.get("N8N_API_KEY", "").strip()

    if not api_key:
        return record_connection_status(
            "n8n",
            False,
            "Enter N8N_API_KEY (in n8n: Settings → n8n API → Create an API Key) to verify & 1-click deploy workflows.",
        )

    t0 = time.perf_counter()
    headers = {"X-N8N-API-KEY": api_key, "Content-Type": "application/json"}
    try:
        async with httpx.AsyncClient(timeout=25) as client:
            list_resp = await client.get(f"{base_url}/api/v1/workflows", headers=headers)
            if list_resp.status_code >= 400:
                return record_connection_status(
                    "n8n", False, f"n8n API HTTP {list_resp.status_code} at {base_url}: {list_resp.text[:170]}"
                )
            existing = {w.get("name"): w.get("id") for w in list_resp.json().get("data", [])}

            deployed_ids = []
            if deploy_workflows:
                for wf_path in sorted(WORKFLOWS_DIR.glob("*.json")):
                    wf_doc = json.loads(wf_path.read_text(encoding="utf-8"))
                    payload = {
                        "name": wf_doc["name"],
                        "nodes": wf_doc["nodes"],
                        "connections": wf_doc["connections"],
                        "settings": wf_doc.get("settings", {"executionOrder": "v1"}),
                    }
                    wf_name = wf_doc["name"]
                    if wf_name in existing:
                        r = await client.put(
                            f"{base_url}/api/v1/workflows/{existing[wf_name]}",
                            headers=headers,
                            json=payload,
                        )
                    else:
                        r = await client.post(
                            f"{base_url}/api/v1/workflows",
                            headers=headers,
                            json=payload,
                        )
                    if r.status_code < 400:
                        deployed_ids.append(r.json().get("id", "ok"))

            ms = int((time.perf_counter() - t0) * 1000)
            if deploy_workflows:
                msg = f"Pushed {len(deployed_ids)}/4 workflows directly into n8n ({base_url}) in {ms}ms!"
            else:
                msg = f"Connected to n8n at {base_url} ({len(existing)} existing workflows found • {ms}ms)"
            return record_connection_status("n8n", True, msg, {"deployed_count": len(deployed_ids)})
    except Exception as exc:
        return record_connection_status(
            "n8n", False, f"Could not reach n8n at {base_url} ({exc}). Make sure n8n is running (`docker compose up -d`)."
        )


def build_oauth_start_url(provider: str, callback_base: str) -> Tuple[bool, str]:
    """Generate real OAuth2 authorization URL for Google/YouTube, TikTok, or Shopify."""
    cfg = load_raw_settings()
    cb = f"{callback_base.rstrip('/')}/api/oauth/{provider}/callback"

    if provider == "youtube":
        cid = cfg.get("GOOGLE_CLIENT_ID", "").strip()
        if not cid:
            return False, "Save your GOOGLE_CLIENT_ID on the Setup page first, then click Connect YouTube OAuth."
        q = urllib.parse.urlencode(
            {
                "client_id": cid,
                "redirect_uri": cb,
                "response_type": "code",
                "scope": "https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube.readonly",
                "access_type": "offline",
                "prompt": "consent",
            }
        )
        return True, f"https://accounts.google.com/o/oauth2/v2/auth?{q}"

    if provider == "tiktok":
        ckey = cfg.get("TIKTOK_CLIENT_KEY", "").strip()
        if not ckey:
            return False, "Save your TIKTOK_CLIENT_KEY on the Setup page first, then click Connect TikTok OAuth."
        q = urllib.parse.urlencode(
            {
                "client_key": ckey,
                "redirect_uri": cb,
                "response_type": "code",
                "scope": "user.info.basic,video.publish,video.upload",
                "state": "pulseagent_tiktok",
            }
        )
        return True, f"https://www.tiktok.com/v2/auth/authorize/?{q}"

    if provider == "shopify":
        domain = _clean_shopify_domain(cfg.get("SHOPIFY_STORE_DOMAIN", ""))
        cid = cfg.get("SHOPIFY_CLIENT_ID", "").strip()
        if not (domain and cid):
            return False, "Save SHOPIFY_STORE_DOMAIN and SHOPIFY_CLIENT_ID first (or paste a Direct Admin shpat_ token)."
        q = urllib.parse.urlencode(
            {
                "client_id": cid,
                "scope": "read_products,write_products,read_orders,write_inventory",
                "redirect_uri": cb,
                "state": "pulseagent_shopify",
            }
        )
        return True, f"https://{domain}/admin/oauth/authorize?{q}"

    return False, f"Unsupported OAuth provider: {provider}"


async def exchange_oauth_callback(provider: str, params: Dict[str, str], callback_base: str) -> Tuple[bool, str]:
    """Exchange authorization `code` from Google, TikTok, or Shopify for permanent tokens & save."""
    cfg = load_raw_settings()
    code = params.get("code", "").strip()
    if not code:
        return False, params.get("error_description") or params.get("error") or "Missing OAuth authorization code."

    cb = f"{callback_base.rstrip('/')}/api/oauth/{provider}/callback"
    async with httpx.AsyncClient(timeout=20) as client:
        if provider == "youtube":
            r = await client.post(
                "https://oauth2.googleapis.com/token",
                data={
                    "code": code,
                    "client_id": cfg.get("GOOGLE_CLIENT_ID", ""),
                    "client_secret": cfg.get("GOOGLE_CLIENT_SECRET", ""),
                    "redirect_uri": cb,
                    "grant_type": "authorization_code",
                },
            )
            if r.status_code >= 400:
                return False, f"Google token exchange failed: {r.text[:180]}"
            d = r.json()
            cfg["YOUTUBE_OAUTH_ACCESS_TOKEN"] = d.get("access_token", "")
            if d.get("refresh_token"):
                cfg["YOUTUBE_REFRESH_TOKEN"] = d["refresh_token"]
            save_raw_settings(cfg)
            await test_youtube()
            return True, "YouTube OAuth2 connected & refresh token saved!"

        if provider == "tiktok":
            r = await client.post(
                "https://open.tiktokapis.com/v2/oauth/token/",
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                data={
                    "client_key": cfg.get("TIKTOK_CLIENT_KEY", ""),
                    "client_secret": cfg.get("TIKTOK_CLIENT_SECRET", ""),
                    "code": code,
                    "grant_type": "authorization_code",
                    "redirect_uri": cb,
                },
            )
            if r.status_code >= 400:
                return False, f"TikTok token exchange failed: {r.text[:180]}"
            d = r.json()
            cfg["TIKTOK_ACCESS_TOKEN"] = d.get("access_token", "")
            if d.get("refresh_token"):
                cfg["TIKTOK_REFRESH_TOKEN"] = d["refresh_token"]
            save_raw_settings(cfg)
            await test_tiktok()
            return True, "TikTok Content Posting OAuth2 connected!"

        if provider == "shopify":
            domain = _clean_shopify_domain(cfg.get("SHOPIFY_STORE_DOMAIN", ""))
            r = await client.post(
                f"https://{domain}/admin/oauth/access_token",
                json={
                    "client_id": cfg.get("SHOPIFY_CLIENT_ID", ""),
                    "client_secret": cfg.get("SHOPIFY_CLIENT_SECRET", ""),
                    "code": code,
                },
            )
            if r.status_code >= 400:
                return False, f"Shopify OAuth failed: {r.text[:180]}"
            cfg["SHOPIFY_ADMIN_ACCESS_TOKEN"] = r.json().get("access_token", "")
            save_raw_settings(cfg)
            await test_shopify()
            return True, f"Shopify store {domain} connected via OAuth!"

    return False, "Unknown provider"
