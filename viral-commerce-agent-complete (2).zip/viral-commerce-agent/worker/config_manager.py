#!/usr/bin/env python3
"""
Live Configuration, Secret Masking & .env Synchronization Manager
-----------------------------------------------------------------
Powers the `/setup` page so every credential and agent rule edited in the browser:
1. Persists safely in `data/settings.json`
2. Writes a clean `.env` file (shared with Docker Compose & n8n)
3. Hot-reloads into `os.environ` immediately without restarting the server
4. Masks secrets (`••••••••abcd`) when sent to the frontend UI
"""

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Set

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
ENV_FILE = BASE_DIR / ".env"
SETTINGS_FILE = DATA_DIR / "settings.json"
STATUS_FILE = DATA_DIR / "connection_status.json"

DATA_DIR.mkdir(parents=True, exist_ok=True)

MASK_PREFIX = "••••••••"

# Default schema values for all settings
DEFAULT_SETTINGS: Dict[str, Any] = {
    # 1. Agent Behavior, Video Stack & Store Rules
    "AUTONOMY_MODE": "hybrid_autonomy",  # hybrid_autonomy | approval_queue | full_autopilot
    "BUILT_IN_SCHEDULER": "enabled",  # enabled (single-container cloud mode) | external_n8n
    "SHORTS_NICHE_STYLE": "pixar_micro_lore",
    "CUSTOM_SHORTS_PROMPT": "Write an emotional 3D Pixar-style micro-story with a shocking 2-second curiosity hook and a twist ending in 42 words.",
    "PRODUCT_NICHE_FOCUS": "Smart Home, Everyday Carry & Problem-Solving Tech Gadgets",
    "AGENT_TIMEZONE": "Africa/Bangui",
    "AUDIENCE_TZ_OFFSET_HOURS": "1",
    "SHORTS_PER_DAY": "3",
    "DEFAULT_VOICE": "en-US-ChristopherNeural",
    "DEFAULT_AD_VOICE": "en-US-AriaNeural",
    "VIDEO_RESOLUTION": "720x1280",  # 720x1280 | 1080x1920
    "MIN_PRODUCT_MARGIN_PCT": "65",
    "STORE_BRAND_NAME": "TrendPulse Studio",
    "DEFAULT_MARKUP_MULTIPLIER": "3.2",
    "DEFAULT_CTA_BANNER": "40% OFF TODAY • LINK IN BIO",
    "PUBLIC_DASHBOARD_URL": "http://localhost:8000",
    "PUBLIC_MEDIA_BASE_URL": "",
    "AGENT_INTERNAL_SECRET": "",

    # 2. n8n Orchestrator Connection
    "N8N_BASE_URL": "http://localhost:5678",
    "N8N_API_KEY": "",
    "N8N_APPROVAL_WEBHOOK_URL": "http://localhost:5678/webhook/approve-product-launch",

    # 3. AI Brain (LLM — OpenAI / Groq / OpenRouter / Ollama)
    "LLM_PROVIDER": "openai",
    "LLM_BASE_URL": "https://api.openai.com/v1",
    "LLM_API_KEY": "",
    "LLM_MODEL": "gpt-4o-mini",

    # 4. YouTube Shorts (Data API v3 + OAuth2)
    "YOUTUBE_API_KEY": "",
    "GOOGLE_CLIENT_ID": "",
    "GOOGLE_CLIENT_SECRET": "",
    "YOUTUBE_REFRESH_TOKEN": "",
    "YOUTUBE_OAUTH_ACCESS_TOKEN": "",

    # 5. Instagram Reels & Stories (Meta Graph API v21)
    "IG_BUSINESS_USER_ID": "",
    "META_APP_ID": "",
    "META_APP_SECRET": "",
    "META_GRAPH_ACCESS_TOKEN": "",

    # 6. TikTok Content Posting API v2 (Feed & Stories)
    "TIKTOK_CLIENT_KEY": "",
    "TIKTOK_CLIENT_SECRET": "",
    "TIKTOK_REFRESH_TOKEN": "",
    "TIKTOK_ACCESS_TOKEN": "",

    # 7. Shopify Admin API
    "SHOPIFY_STORE_DOMAIN": "",
    "SHOPIFY_CLIENT_ID": "",
    "SHOPIFY_CLIENT_SECRET": "",
    "SHOPIFY_ADMIN_ACCESS_TOKEN": "",
    "SHOPIFY_COLLECTION_TITLE": "Trending Viral Picks",

    # 8. Amazon Selling Partner API (SP-API)
    "AMAZON_LWA_CLIENT_ID": "",
    "AMAZON_LWA_CLIENT_SECRET": "",
    "AMAZON_SP_REFRESH_TOKEN": "",
    "AMAZON_LWA_ACCESS_TOKEN": "",
    "AMAZON_SELLER_ID": "",
    "AMAZON_MARKETPLACE_ID": "ATVPDKIKX0DER",

    # 9. TikTok Shop Partner API
    "TIKTOK_SHOP_APP_KEY": "",
    "TIKTOK_SHOP_APP_SECRET": "",
    "TIKTOK_SHOP_ACCESS_TOKEN": "",
    "TIKTOK_SHOP_CIPHER": "",

    # 10. Daily Notifications (WhatsApp Cloud API & Email)
    "WHATSAPP_PHONE_NUMBER_ID": "",
    "WHATSAPP_ACCESS_TOKEN": "",
    "WHATSAPP_RECIPIENT_TO": "",
    "NOTIFY_EMAIL_TO": "",
    "EMAIL_FROM": "agent@yourdomain.com",
    "RESEND_API_KEY": "",
    "SMTP_HOST": "smtp.gmail.com",
    "SMTP_PORT": "587",
    "SMTP_USER": "",
    "SMTP_PASS": "",
}

SECRET_KEYS: Set[str] = {
    "AGENT_INTERNAL_SECRET",
    "N8N_API_KEY",
    "LLM_API_KEY",
    "YOUTUBE_API_KEY",
    "GOOGLE_CLIENT_SECRET",
    "YOUTUBE_REFRESH_TOKEN",
    "YOUTUBE_OAUTH_ACCESS_TOKEN",
    "META_APP_SECRET",
    "META_GRAPH_ACCESS_TOKEN",
    "TIKTOK_CLIENT_SECRET",
    "TIKTOK_REFRESH_TOKEN",
    "TIKTOK_ACCESS_TOKEN",
    "SHOPIFY_CLIENT_SECRET",
    "SHOPIFY_ADMIN_ACCESS_TOKEN",
    "AMAZON_LWA_CLIENT_SECRET",
    "AMAZON_SP_REFRESH_TOKEN",
    "AMAZON_LWA_ACCESS_TOKEN",
    "TIKTOK_SHOP_APP_SECRET",
    "TIKTOK_SHOP_ACCESS_TOKEN",
    "WHATSAPP_ACCESS_TOKEN",
    "RESEND_API_KEY",
    "SMTP_PASS",
}


def _parse_dotenv_if_exists() -> Dict[str, str]:
    parsed: Dict[str, str] = {}
    if not ENV_FILE.exists():
        return parsed
    for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
        s = line.strip()
        if not s or s.startswith("#") or "=" not in s:
            continue
        k, v = s.split("=", 1)
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        parsed[k] = v
    return parsed


def load_raw_settings() -> Dict[str, str]:
    """Load full unmasked settings, merging defaults -> .env -> settings.json -> active env."""
    merged: Dict[str, str] = {k: str(v) for k, v in DEFAULT_SETTINGS.items()}
    env_vals = _parse_dotenv_if_exists()
    for k, v in env_vals.items():
        if k in merged and v:
            merged[k] = v

    if SETTINGS_FILE.exists():
        try:
            saved = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
            for k, v in saved.items():
                if k in merged and v is not None:
                    merged[k] = str(v)
        except Exception:
            pass
    else:
        # Also pull any pre-set environment variables on first boot
        for k in merged:
            if os.environ.get(k):
                merged[k] = os.environ[k]
        save_raw_settings(merged)

    # Ensure os.environ stays hydrated
    for k, v in merged.items():
        os.environ[k] = str(v)

    return merged


def save_raw_settings(settings: Dict[str, str]) -> Dict[str, str]:
    """Persist settings to `data/settings.json`, sync `.env`, and hot-reload `os.environ`."""
    clean: Dict[str, str] = {}
    for k, default_val in DEFAULT_SETTINGS.items():
        val = settings.get(k, default_val)
        clean[k] = "" if val is None else str(val).strip()
        os.environ[k] = clean[k]

    SETTINGS_FILE.write_text(json.dumps(clean, indent=2), encoding="utf-8")
    _write_dotenv(clean)
    return clean


def update_settings_from_ui(incoming: Dict[str, Any]) -> Dict[str, str]:
    """
    Merge form updates from `/setup`.
    If a secret field still starts with `••••••••`, keep the existing stored secret untouched!
    """
    current = load_raw_settings()
    for k, raw_val in incoming.items():
        if k not in DEFAULT_SETTINGS:
            continue
        val_str = "" if raw_val is None else str(raw_val).strip()
        if k in SECRET_KEYS and val_str.startswith(MASK_PREFIX):
            continue
        current[k] = val_str
    return save_raw_settings(current)


def mask_value(key: str, value: str) -> str:
    if not value:
        return ""
    if key not in SECRET_KEYS:
        return value
    if len(value) <= 6:
        return MASK_PREFIX
    return f"{MASK_PREFIX}{value[-4:]}"


def get_masked_settings_for_ui() -> Dict[str, Any]:
    raw = load_raw_settings()
    masked = {k: mask_value(k, v) for k, v in raw.items()}
    configured_flags = {k: bool(v) for k, v in raw.items()}
    return {
        "values": masked,
        "configured": configured_flags,
        "statuses": load_connection_statuses(),
        "readiness": compute_readiness_summary(raw, load_connection_statuses()),
    }


def _write_dotenv(settings: Dict[str, str]) -> None:
    lines = [
        "# Auto-generated & synced by PulseAgent Setup Page (/setup)",
        f"# Last updated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}",
        "",
    ]
    for k, v in settings.items():
        safe = v.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "")
        if " " in safe or "#" in safe or ";" in safe:
            lines.append(f'{k}="{safe}"')
        else:
            lines.append(f"{k}={safe}")
    ENV_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")


def load_connection_statuses() -> Dict[str, Dict]:
    if not STATUS_FILE.exists():
        return {}
    try:
        return json.loads(STATUS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def record_connection_status(provider: str, ok: bool, message: str, details: Dict = None) -> Dict:
    statuses = load_connection_statuses()
    entry = {
        "provider": provider,
        "ok": ok,
        "status": "connected" if ok else "error",
        "message": message,
        "details": details or {},
        "checked_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
    }
    statuses[provider] = entry
    STATUS_FILE.write_text(json.dumps(statuses, indent=2), encoding="utf-8")
    return entry


def compute_readiness_summary(raw: Dict[str, str], statuses: Dict[str, Dict]) -> Dict[str, Any]:
    """Compute genuine setup completion across the 5 pillars of the agent."""
    checks = {
        "ffmpeg_tts": True,  # Local FFmpeg + edge-tts engine
        "llm": bool(raw.get("LLM_API_KEY")),
        "n8n": bool(raw.get("N8N_API_KEY") or raw.get("N8N_BASE_URL")),
        "youtube": bool(raw.get("YOUTUBE_OAUTH_ACCESS_TOKEN") or raw.get("YOUTUBE_REFRESH_TOKEN") or raw.get("YOUTUBE_API_KEY")),
        "instagram": bool(raw.get("IG_BUSINESS_USER_ID") and raw.get("META_GRAPH_ACCESS_TOKEN")),
        "tiktok": bool(raw.get("TIKTOK_ACCESS_TOKEN") or raw.get("TIKTOK_REFRESH_TOKEN")),
        "shopify": bool(raw.get("SHOPIFY_STORE_DOMAIN") and raw.get("SHOPIFY_ADMIN_ACCESS_TOKEN")),
        "amazon": bool(raw.get("AMAZON_LWA_CLIENT_ID") and raw.get("AMAZON_SP_REFRESH_TOKEN") and raw.get("AMAZON_SELLER_ID")),
        "tiktok_shop": bool(raw.get("TIKTOK_SHOP_APP_KEY") and raw.get("TIKTOK_SHOP_ACCESS_TOKEN")),
        "whatsapp": bool(raw.get("WHATSAPP_PHONE_NUMBER_ID") and raw.get("WHATSAPP_ACCESS_TOKEN") and raw.get("WHATSAPP_RECIPIENT_TO")),
        "email": bool(raw.get("NOTIFY_EMAIL_TO") and (raw.get("RESEND_API_KEY") or raw.get("SMTP_USER"))),
    }
    configured_count = sum(1 for v in checks.values() if v)
    verified_count = sum(1 for k in checks if statuses.get(k, {}).get("ok"))
    return {
        "configured_count": configured_count,
        "total_integrations": len(checks),
        "verified_live_count": verified_count,
        "percent": int(round((configured_count / len(checks)) * 100)),
        "items": checks,
    }
