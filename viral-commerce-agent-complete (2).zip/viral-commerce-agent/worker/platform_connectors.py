#!/usr/bin/env python3
"""
Omnichannel Store, Social Video & Notification Connectors
---------------------------------------------------------
Supports Live API execution when credentials are set in environment variables,
and transparent Sandbox Dry-Run receipts when testing locally before connecting live accounts.
"""

import hashlib
import hmac
import json
import os
import smtplib
import time
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Dict

import httpx


async def publish_to_shopify(product: Dict) -> Dict:
    """Create conversion-optimized product listing on Shopify Admin API."""
    shop_domain = os.getenv("SHOPIFY_STORE_DOMAIN", "").strip()
    access_token = os.getenv("SHOPIFY_ADMIN_ACCESS_TOKEN", "").strip()

    payload = {
        "product": {
            "title": product["title"],
            "body_html": product["store_html_description"],
            "vendor": os.getenv("STORE_BRAND_NAME") or product.get("brand", "TrendPulse Labs"),
            "product_type": os.getenv("SHOPIFY_COLLECTION_TITLE") or product.get("category", "Viral Gadgets"),
            "tags": ", ".join(product.get("tags", ["viral", "trending", "featured"])),
            "status": "active",
            "variants": [
                {
                    "price": f"{product['recommended_price_usd']:.2f}",
                    "compare_at_price": f"{product.get('compare_at_price_usd', round(product['recommended_price_usd']*1.45, 2)):.2f}",
                    "sku": product["sku"],
                    "inventory_management": "shopify",
                    "inventory_quantity": 150,
                }
            ],
        }
    }

    if shop_domain and access_token:
        url = f"https://{shop_domain}/admin/api/2025-01/products.json"
        async with httpx.AsyncClient(timeout=25) as client:
            resp = await client.post(
                url,
                headers={
                    "X-Shopify-Access-Token": access_token,
                    "Content-Type": "application/json",
                },
                json=payload,
            )
            resp.raise_for_status()
            data = resp.json()["product"]
            return {
                "platform": "shopify",
                "mode": "live",
                "listing_id": str(data["id"]),
                "url": f"https://{shop_domain}/products/{data.get('handle', '')}",
                "status": "published",
            }

    slug = product["sku"].lower().replace("_", "-")
    return {
        "platform": "shopify",
        "mode": "sandbox_ready",
        "listing_id": f"shp_{abs(hash(product['sku'])) % 900000 + 100000}",
        "url": f"https://your-store.myshopify.com/products/{slug}",
        "status": "published_sandbox",
        "api_endpoint": "POST https://{SHOPIFY_STORE_DOMAIN}/admin/api/2025-01/products.json",
    }


async def publish_to_amazon_sp_api(product: Dict) -> Dict:
    """Publish SKU listing via Amazon Selling Partner API (Listings Items v2021-08-01)."""
    lwa_client_id = os.getenv("AMAZON_LWA_CLIENT_ID", "").strip()
    lwa_client_secret = os.getenv("AMAZON_LWA_CLIENT_SECRET", "").strip()
    refresh_token = os.getenv("AMAZON_SP_REFRESH_TOKEN", "").strip()
    seller_id = os.getenv("AMAZON_SELLER_ID", "").strip()
    marketplace_id = os.getenv("AMAZON_MARKETPLACE_ID", "ATVPDKIKX0DER").strip()

    sp_payload = {
        "productType": "PRODUCT",
        "requirements": "LISTING",
        "attributes": {
            "item_name": [{"value": product["title"], "marketplace_id": marketplace_id}],
            "product_description": [{"value": product["amazon_description"], "marketplace_id": marketplace_id}],
            "bullet_point": [
                {"value": bp, "marketplace_id": marketplace_id}
                for bp in product.get("bullet_points", [])[:5]
            ],
            "purchasable_offer": [
                {
                    "marketplace_id": marketplace_id,
                    "currency": "USD",
                    "our_price": [{"schedule": [{"value_with_tax": product["recommended_price_usd"]}]}],
                }
            ],
            "fulfillment_availability": [{"fulfillment_channel_code": "DEFAULT", "quantity": 100}],
        },
    }

    if lwa_client_id and lwa_client_secret and refresh_token and seller_id:
        async with httpx.AsyncClient(timeout=25) as client:
            tok = await client.post(
                "https://api.amazon.com/auth/o2/token",
                data={
                    "grant_type": "refresh_token",
                    "refresh_token": refresh_token,
                    "client_id": lwa_client_id,
                    "client_secret": lwa_client_secret,
                },
            )
            tok.raise_for_status()
            access_token = tok.json()["access_token"]
            endpoint = f"https://sellingpartnerapi-na.amazon.com/listings/2021-08-01/items/{seller_id}/{product['sku']}?marketplaceIds={marketplace_id}"
            resp = await client.put(
                endpoint,
                headers={"x-amz-access-token": access_token, "Content-Type": "application/json"},
                json=sp_payload,
            )
            resp.raise_for_status()
            return {
                "platform": "amazon_sp_api",
                "mode": "live",
                "sku": product["sku"],
                "submission_id": resp.json().get("submissionId", "submitted"),
                "status": "published",
            }

    return {
        "platform": "amazon_sp_api",
        "mode": "sandbox_ready",
        "sku": product["sku"],
        "asin_placeholder": f"B0{abs(hash(product['title'])) % 89999999 + 10000000}",
        "url": f"https://www.amazon.com/dp/B0{abs(hash(product['title'])) % 89999999 + 10000000}",
        "status": "published_sandbox",
        "api_endpoint": "PUT https://sellingpartnerapi-na.amazon.com/listings/2021-08-01/items/{sellerId}/{sku}",
    }


def _sign_tiktok_shop_request(app_secret: str, path: str, params: Dict[str, str], body_str: str) -> str:
    sorted_params = "".join(f"{k}{params[k]}" for k in sorted(params.keys()) if k not in ("sign", "access_token"))
    base_str = f"{app_secret}{path}{sorted_params}{body_str}{app_secret}"
    return hmac.new(app_secret.encode("utf-8"), base_str.encode("utf-8"), hashlib.sha256).hexdigest()


async def publish_to_tiktok_shop(product: Dict) -> Dict:
    """Create TikTok Shop product listing via signed Partner Open API v202309."""
    app_key = os.getenv("TIKTOK_SHOP_APP_KEY", "").strip()
    app_secret = os.getenv("TIKTOK_SHOP_APP_SECRET", "").strip()
    access_token = os.getenv("TIKTOK_SHOP_ACCESS_TOKEN", "").strip()
    shop_cipher = os.getenv("TIKTOK_SHOP_CIPHER", "").strip()

    body = {
        "title": product["title"],
        "description": product["store_html_description"],
        "category_id": product.get("tiktok_category_id", "601226"),
        "skus": [
            {
                "seller_sku": product["sku"],
                "price": {"amount": f"{product['recommended_price_usd']:.2f}", "currency": "USD"},
                "inventory": [{" quantity": 120}],
            }
        ],
    }

    if app_key and app_secret and access_token and shop_cipher:
        path = "/product/202309/products"
        params = {
            "app_key": app_key,
            "timestamp": str(int(time.time())),
            "shop_cipher": shop_cipher,
        }
        body_str = json.dumps(body, separators=(",", ":"))
        params["sign"] = _sign_tiktok_shop_request(app_secret, path, params, body_str)
        params["access_token"] = access_token
        async with httpx.AsyncClient(timeout=25) as client:
            resp = await client.post(
                f"https://open-api.tiktokglobalshop.com{path}",
                params=params,
                headers={"Content-Type": "application/json", "x-tts-access-token": access_token},
                content=body_str,
            )
            resp.raise_for_status()
            return {
                "platform": "tiktok_shop",
                "mode": "live",
                "product_id": resp.json().get("data", {}).get("product_id", "created"),
                "status": "published",
            }

    return {
        "platform": "tiktok_shop",
        "mode": "sandbox_ready",
        "product_id": f"tts_{abs(hash(product['sku'] + 'tt')) % 9000000 + 1000000}",
        "url": f"https://shop.tiktok.com/view/product/{abs(hash(product['sku'])) % 9000000 + 1000000}",
        "status": "published_sandbox",
        "api_endpoint": "POST https://open-api.tiktokglobalshop.com/product/202309/products",
    }


async def send_daily_notifications(summary: Dict) -> Dict:
    """
    Dispatch Daily Digest / Product Approval Alert to:
    1. WhatsApp Business Cloud API (`WHATSAPP_ACCESS_TOKEN` + `WHATSAPP_PHONE_NUMBER_ID` + `WHATSAPP_RECIPIENT_TO`)
    2. Email via Resend API (`RESEND_API_KEY`) or SMTP (`SMTP_HOST`, `SMTP_USER`, `SMTP_PASS`)
    """
    wa_token = os.getenv("WHATSAPP_ACCESS_TOKEN", "").strip()
    wa_phone_id = os.getenv("WHATSAPP_PHONE_NUMBER_ID", "").strip()
    wa_to = os.getenv("WHATSAPP_RECIPIENT_TO", "").strip()

    whatsapp_text = (
        f"🚀 *Viral AI Agent Daily Digest ({summary['date']})*\n\n"
        f"🎬 *Animated Shorts Auto-Posted:* {summary['shorts_published_count']} (YT Shorts, TikTok, IG Reels)\n"
        f"🛍️ *New Viral Products Shortlisted:* {summary['pending_approvals_count']} awaiting your 1-click approval\n"
        f"🏪 *Live Multi-Store Products:* {summary['published_products_count']} synced on Shopify, Amazon & TikTok Shop\n"
        f"📢 *Product Ad Videos Scheduled:* {summary['ad_placements_count']} across Shorts, Reels & Stories\n\n"
        f"👉 Review & Approve Products: {summary.get('dashboard_url', 'http://localhost:8000')}"
    )

    wa_result = {"channel": "whatsapp", "mode": "sandbox_preview", "message_preview": whatsapp_text}
    if wa_token and wa_phone_id and wa_to:
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.post(
                f"https://graph.facebook.com/v21.0/{wa_phone_id}/messages",
                headers={"Authorization": f"Bearer {wa_token}", "Content-Type": "application/json"},
                json={
                    "messaging_product": "whatsapp",
                    "to": wa_to,
                    "type": "text",
                    "text": {"preview_url": True, "body": whatsapp_text},
                },
            )
            wa_result = {
                "channel": "whatsapp",
                "mode": "live",
                "http_status": resp.status_code,
                "response": resp.json() if resp.status_code < 500 else resp.text,
            }

    # Email via Resend or SMTP
    resend_key = os.getenv("RESEND_API_KEY", "").strip()
    notify_email = os.getenv("NOTIFY_EMAIL_TO", "").strip()
    smtp_host = os.getenv("SMTP_HOST", "").strip()

    html_body = f"""
    <div style="font-family:Inter,Arial,sans-serif;max-width:600px;margin:0 auto;background:#0f172a;color:#f8fafc;padding:28px;border-radius:14px;">
      <h2 style="margin:0 0 8px;color:#38bdf8;">Viral AI Commerce & Shorts — Daily Digest</h2>
      <p style="color:#94a3b8;margin-top:0;">Date: {summary['date']} • Mode: Hybrid Autonomy (Auto Shorts / Approve Products)</p>
      <hr style="border:none;border-top:1px solid #1e293b;margin:18px 0;" />
      <ul style="line-height:1.8;padding-left:18px;">
        <li><strong>Animated Shorts Auto-Posted:</strong> {summary['shorts_published_count']} videos live/scheduled</li>
        <li><strong>Viral Products Shortlisted:</strong> {summary['pending_approvals_count']} ready for 1-click store launch</li>
        <li><strong>Published Store Listings:</strong> {summary['published_products_count']} live on Shopify, Amazon & TikTok Shop</li>
        <li><strong>Product Ad Placements:</strong> {summary['ad_placements_count']} across YT Shorts, IG Reels/Stories & TikTok</li>
      </ul>
      <a href="{summary.get('dashboard_url', 'http://localhost:8000')}"
         style="display:inline-block;margin-top:14px;background:#6366f1;color:#fff;text-decoration:none;padding:12px 20px;border-radius:8px;font-weight:600;">
        Open Approval & Command Dashboard
      </a>
    </div>
    """

    email_result = {"channel": "email", "mode": "sandbox_preview", "subject": f"Daily Viral Agent Digest — {summary['date']}"}
    if resend_key and notify_email:
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.post(
                "https://api.resend.com/emails",
                headers={"Authorization": f"Bearer {resend_key}", "Content-Type": "application/json"},
                json={
                    "from": os.getenv("EMAIL_FROM", "agent@yourdomain.com"),
                    "to": [notify_email],
                    "subject": f"🚀 Viral Agent Daily Digest ({summary['date']})",
                    "html": html_body,
                },
            )
            email_result = {"channel": "email", "mode": "live_resend", "http_status": resp.status_code}
    elif smtp_host and notify_email:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = f"Viral Agent Daily Digest ({summary['date']})"
        msg["From"] = os.getenv("SMTP_USER", "agent@localhost")
        msg["To"] = notify_email
        msg.attach(MIMEText(whatsapp_text, "plain"))
        msg.attach(MIMEText(html_body, "html"))
        with smtplib.SMTP(smtp_host, int(os.getenv("SMTP_PORT", "587"))) as server:
            server.starttls()
            if os.getenv("SMTP_USER") and os.getenv("SMTP_PASS"):
                server.login(os.getenv("SMTP_USER", ""), os.getenv("SMTP_PASS", ""))
            server.sendmail(msg["From"], [notify_email], msg.as_string())
        email_result = {"channel": "email", "mode": "live_smtp", "status": "sent"}

    return {"whatsapp": wa_result, "email": email_result}
