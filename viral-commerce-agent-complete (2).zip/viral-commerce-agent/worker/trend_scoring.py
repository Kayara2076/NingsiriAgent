#!/usr/bin/env python3
"""
Trend Style Analyzer, Viral Posting Timeline Optimizer & E-Commerce Product Scoring Engine.
"""

from datetime import datetime, timedelta, timezone
from typing import Dict, List


# Optimal posting windows (UTC offsets adjustable via AUDIENCE_TZ_OFFSET_HOURS)
# Derived from short-form engagement velocity curves across YT Shorts, TikTok, and IG Reels/Stories.
PLATFORM_PEAK_WINDOWS = {
    "youtube_shorts": [
        {"hour": 12, "minute": 15, "score": 94, "reason": "Midday lunch scroll surge + 2h Shorts shelf seed window"},
        {"hour": 18, "minute": 0, "score": 98, "reason": "Prime evening mobile session peak (highest retention velocity)"},
        {"hour": 21, "minute": 0, "score": 91, "reason": "Late-night binge loop window"},
    ],
    "tiktok": [
        {"hour": 11, "minute": 30, "score": 90, "reason": "Midday FYP batch test window"},
        {"hour": 19, "minute": 0, "score": 99, "reason": "Highest global FYP swipe & share velocity"},
        {"hour": 21, "minute": 30, "score": 95, "reason": "Impulse shopping & #TikTokMadeMeBuyIt conversion spike"},
    ],
    "instagram_reels": [
        {"hour": 11, "minute": 0, "score": 92, "reason": "Morning break Reels + Stories tap-through surge"},
        {"hour": 18, "minute": 30, "score": 97, "reason": "Commute & early evening DM-share peak"},
        {"hour": 20, "minute": 45, "score": 93, "reason": "Evening Stories sticker link CTR peak"},
    ],
}


TRENDING_ANIMATION_STYLES = [
    {
        "id": "pixar_micro_lore",
        "name": "3D Stylized Micro-SciFi / Pixar Lore",
        "velocity_score": 97,
        "retention_avg": "84% viewed-vs-swiped",
        "pacing": "Fast 2.4s cuts + curiosity open-loop hook in first 1.8s",
        "visual_prompt_prefix": "Vertical 9:16 3D Pixar-style stylized animation render, expressive lighting, shallow depth of field,",
        "voice": "en-US-ChristopherNeural",
        "top_hashtags": ["#shorts", "#aianimation", "#scifistories", "#pixarstyle", "#viralstory"],
    },
    {
        "id": "dark_stoic_anime",
        "name": "Neon Cyberpunk Anime / Mindset Parables",
        "velocity_score": 93,
        "retention_avg": "81% viewed-vs-swiped",
        "pacing": "Dramatic slow push-in + high-contrast yellow kinetic captions",
        "visual_prompt_prefix": "Vertical 9:16 cinematic Makoto Shinkai anime frame, dramatic neon rain reflections, glowing rim light,",
        "voice": "en-US-GuyNeural",
        "top_hashtags": ["#shorts", "#animeedit", "#mindset", "#cyberpunk", "#fyp"],
    },
    {
        "id": "cozy_isometric_worlds",
        "name": "Miniature Isometric Worlds & Untold Facts",
        "velocity_score": 91,
        "retention_avg": "79% viewed-vs-swiped",
        "pacing": "Warm macro tilt-shift zoom + soothing loopable ending",
        "visual_prompt_prefix": "Vertical 9:16 miniature tilt-shift 3D diorama, warm golden lanterns, ultra detailed isometric world,",
        "voice": "en-US-AriaNeural",
        "top_hashtags": ["#shorts", "#miniatureworld", "#didyouknow", "#satisfying", "#viral"],
    },
]


def compute_best_publish_timeline(tz_offset_hours: int = 1) -> Dict[str, Dict]:
    """
    Calculate the next optimal posting timestamp for YT Shorts, TikTok, and Instagram
    in the target audience timezone.
    """
    tz = timezone(timedelta(hours=tz_offset_hours))
    now = datetime.now(tz)
    schedule: Dict[str, Dict] = {}

    for platform, windows in PLATFORM_PEAK_WINDOWS.items():
        candidates = []
        for day_offset in (0, 1):
            base_day = now + timedelta(days=day_offset)
            for w in windows:
                slot = base_day.replace(hour=w["hour"], minute=w["minute"], second=0, microsecond=0)
                if slot > now + timedelta(minutes=20):
                    candidates.append((slot, w))
        # Pick the soonest high-score window (prefer score >= 95 if within 16 hours)
        best_slot, best_meta = candidates[0]
        for slot, meta in candidates:
            if (slot - now).total_seconds() <= 16 * 3600 and meta["score"] > best_meta["score"]:
                best_slot, best_meta = slot, meta
        schedule[platform] = {
            "iso_timestamp": best_slot.isoformat(),
            "display_time": best_slot.strftime("%a %b %d, %I:%M %p") + f" (UTC+{tz_offset_hours})",
            "viral_window_score": best_meta["score"],
            "reason": best_meta["reason"],
        }
    return schedule


def score_product_candidate(candidate: Dict) -> Dict:
    """
    Compute weighted 100-point Viral E-Commerce Score:
    - 30% Demand Surge Velocity (Amazon Movers & Shakers + TikTok Shop search velocity)
    - 25% Short-Form Video 'Wow' Hook Factor (visual demonstration appeal)
    - 25% Gross Margin Health (target >= 65% gross margin / 3x markup)
    - 20% Low Competition & Lightweight Fulfillment
    """
    cost = float(candidate.get("supplier_cost_usd", 12.0))
    price = float(candidate.get("recommended_price_usd", 39.99))
    gross_margin_pct = round(((price - cost) / max(price, 0.01)) * 100, 1)

    demand = float(candidate.get("demand_velocity", 90))
    wow_factor = float(candidate.get("video_wow_score", 92))
    margin_score = min(100.0, max(35.0, gross_margin_pct * 1.32))
    fulfillment_score = float(candidate.get("fulfillment_ease", 88))

    composite = round(
        0.30 * demand + 0.25 * wow_factor + 0.25 * margin_score + 0.20 * fulfillment_score,
        1,
    )

    return {
        **candidate,
        "gross_margin_pct": gross_margin_pct,
        "estimated_profit_per_unit_usd": round(price - cost - (price * 0.12), 2),
        "viral_composite_score": composite,
        "verdict": "STRONG SHORTLIST" if composite >= 85 else ("WATCHLIST" if composite >= 72 else "SKIP"),
    }
