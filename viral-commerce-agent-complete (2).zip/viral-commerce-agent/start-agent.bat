@echo off
echo ==========================================================
echo  PulseAgent - 1-Click Beginner Launcher (Windows)
echo ==========================================================

where docker >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Docker Desktop is not installed or not running!
    echo Please install Docker Desktop free from: https://www.docker.com/products/docker-desktop/
    pause
    exit /b 1
)

if not exist .env (
    copy .env.example .env >nul
    echo [OK] Created initial .env configuration file.
)

echo Starting n8n Orchestrator + FFmpeg Video Worker + Setup Hub...
docker compose up -d --build

echo.
echo ==========================================================
echo  SUCCESS! Open these links in your browser:
echo    1. Live Setup Wizard:     http://localhost:8000/setup
echo    2. Command Dashboard:     http://localhost:8000
echo    3. n8n Visual Canvas:     http://localhost:5678
echo ==========================================================
pause
