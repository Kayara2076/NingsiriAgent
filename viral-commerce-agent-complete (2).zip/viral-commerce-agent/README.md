---
title: PulseAgent Viral Shorts & Commerce Hub
emoji: ⚡
colorFrom: indigo
colorTo: cyan
sdk: docker
app_port: 7860
pinned: false
---

# ⚡ PulseAgent — Mobile-Ready Viral Shorts & Omnichannel E-Commerce AI Agent

Runs 100% in the cloud and is controllable from any **Android / iOS mobile browser** (installable to your Home Screen as a PWA).

- **Dashboard:** `/`
- **Live Setup & API Connections Wizard:** `/setup`
- **n8n Workflows:** `n8n-workflows/*.json`
- **Android Step-by-Step Guide:** `ANDROID_PHONE_SETUP_GUIDE.md`
